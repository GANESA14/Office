from flask import Flask, jsonify
import mysql.connector
import joblib
import numpy as np

MODEL_PATH = "risk_model.joblib"
SCHEMA_PATH = "feature_schema.joblib"

model = joblib.load(MODEL_PATH)
schema = joblib.load(SCHEMA_PATH)

MAX_MARKS = schema["max_marks"]
FEATURES = schema["features"]

app = Flask(__name__)

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="risk_ai"
)
cursor = db.cursor(dictionary=True)

def predict(student):
    student["avg_internal_marks"] = (student["avg_internal_marks"] / MAX_MARKS) * 100
    features = np.array([[student[f] for f in FEATURES]])
    return float(model.predict(features)[0])

@app.route("/predict_all")
def predict_all():
    cursor.execute("SELECT * FROM students")
    students = cursor.fetchall()

    results = []

    for s in students:
        data = {
            "incident_count": s["incident_count"],
            "avg_internal_marks": s["avg_internal_marks"],
            "attendance_percentage": s["attendance_percentage"],
            "department_fees_amount": 0,
            "pending_amount": s["fee_due_amount"]
        }

        risk = predict(data)

        # Save risk into DB
        cursor.execute(
            "UPDATE students SET risk_score=%s WHERE id=%s",
            (risk, s["id"])
        )
        db.commit()

        results.append({
            "student": s["student_name"],
            "risk_score": round(risk,2)
        })

    return jsonify(results)

if __name__ == "__main__":
    app.run(port=5000, debug=True)
