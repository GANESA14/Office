import joblib
import numpy as np
from rules import calculate_risk

MODEL_PATH = "risk_model.joblib"
SCHEMA_PATH = "feature_schema.joblib"

model = joblib.load(MODEL_PATH)
schema = joblib.load(SCHEMA_PATH)

MAX_MARKS = schema["max_marks"]
FEATURES = schema["features"]

def validate_inputs(data: dict):
    for key in FEATURES:
        if key not in data:
            raise ValueError(f"Missing feature: {key}")
    if not (0 <= data["avg_internal_marks"] <= MAX_MARKS):
        raise ValueError("Marks out of valid range")
    if not (0 <= data["attendance_percentage"] <= 100):
        raise ValueError("Attendance must be 0–100")
    if data["incident_count"] < 0:
        raise ValueError("Incidents cannot be negative")
    if data["pending_amount"] < 0 or data["department_fees_amount"] < 0:
        raise ValueError("Fee values cannot be negative")

def predict_risk(incident_count, avg_internal_marks, attendance_percentage, department_fees_amount, pending_amount):
    data = {
        "incident_count": incident_count,
        "avg_internal_marks": avg_internal_marks,
        "attendance_percentage": attendance_percentage,
        "department_fees_amount": department_fees_amount,
        "pending_amount": pending_amount
    }
    validate_inputs(data)
    data["avg_internal_marks"] = (data["avg_internal_marks"] / MAX_MARKS) * 100
    features = np.array([[data[f] for f in FEATURES]])
    return float(model.predict(features)[0])

if __name__ == "__main__":
    student = {
        "incident_count": 2,
        "avg_internal_marks": 35,
        "attendance_percentage": 72,
        "department_fees_amount": 5000,
        "pending_amount": 1200,
    }

    iterations = 200

    # Calculate initial rule score before any updates
    initial_rule_score = calculate_risk(student)

    for _ in range(iterations):
        # ML prediction for current student state
        ml_risk = predict_risk(**student)

        # Update student values dynamically
        student["incident_count"] = min(student["incident_count"] + 1, 10)
        student["avg_internal_marks"] = max(student["avg_internal_marks"] - 1, 0)
        student["attendance_percentage"] = max(student["attendance_percentage"] - 0.5, 50)
        student["pending_amount"] = min(student["pending_amount"] + 50, 5000)

    # Calculate final rule score after all updates
    final_rule_score = calculate_risk(student)

    # Single print at the end
    print(f"Initial Rule Score: {initial_rule_score:.2f}, "
          f"Final Rule Score: {final_rule_score:.2f}, "
          f"Last ML Risk: {ml_risk:.2f}, "
          f"Final Student Data: {student}")