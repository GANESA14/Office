import pandas as pd
import mysql.connector

df = pd.read_csv("students.csv")

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="risk_ai"
)
cursor = db.cursor()

for _, row in df.iterrows():
    sql = """
    INSERT INTO students
    (id, student_id, student_name, attendance_percentage,
     avg_internal_marks, fee_due_amount, incident_count,
     created_at, updated_at)
    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """
    cursor.execute(sql, (
        row["id"], row["student_id"], row["student_name"],
        row["attendance_percentage"], row["avg_internal_marks"],
        row["fee_due_amount"], row["incident_count"],
        row["created_at"], row["updated_at"]
    ))

db.commit()
print("CSV Imported into MySQL")
