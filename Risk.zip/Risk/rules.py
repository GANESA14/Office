import math

def sigmoid_cap(risk):
    return 100 / (1 + math.exp(-0.05 * (risk - 50)))

def calculate_risk(student: dict) -> float:
    incidents = int(student.get('incident_count', 0))
    attendance = float(student.get('attendance_percentage', 100))
    marks = float(student.get('avg_internal_marks', 50))
    department_fee = float(student.get('department_fees_amount', 0))
    pending = float(student.get('pending_amount', 0))
    risk = 0
    
    MAX_RISK = 99.0   # or 98.5 if you want more softness

    max_marks = 50
    max_incidents = 10

    # Base risk dynamically
    base_risk = lambda inc: (inc / max_incidents) * 99.9

    if incidents == 10:
        risk = base_risk(incidents)
        if marks >= 40 and attendance >= 85 or pending == 0:
            risk -= base_risk(incidents) * 0.10
        else:
            risk += ((max_marks - min(marks, max_marks)) / max_marks) * 15

    elif incidents == 9:
        risk = base_risk(incidents)
        if marks < 20 or attendance < 75:
            risk = base_risk(max_incidents)
        elif marks >= 35 and attendance >= 85 or pending == 0:
            risk -= base_risk(incidents) * 0.094  # 8/85 ≈ 0.094
        else:
            risk += ((max_marks - min(marks, max_marks)) / max_marks) * 15

    elif incidents == 8:
        risk = base_risk(incidents)
        if marks < 20:
            risk += base_risk(incidents) * 0.1875  # 15/80 ≈ 0.1875
        elif marks >= 35 and attendance >= 85:
            risk -= base_risk(incidents) * 0.133  # 10/75 ≈ 0.133
        else:
            risk += ((max_marks - min(marks, max_marks)) / max_marks) * 12

    elif incidents == 7:
        risk = base_risk(incidents)
        if marks < 20 or attendance < 65:
            risk += base_risk(incidents) * 0.154  # 10/65 ≈ 0.154
        elif marks >= 30 and attendance >= 80:
            risk -= base_risk(incidents) * 0.077  # 5/65 ≈ 0.077
        else:
            risk += ((max_marks - min(marks, max_marks)) / max_marks) * 10

    elif incidents == 6:
        risk = base_risk(incidents)
        if marks < 20:
            risk += base_risk(incidents) * 0.182  # 10/55 ≈ 0.182
        elif marks >= 30 and attendance >= 80:
            risk -= base_risk(incidents) * 0.091  # 5/55 ≈ 0.091
        else:
            risk += ((max_marks - min(marks, max_marks)) / max_marks) * 8

    elif incidents == 5:
        risk = base_risk(incidents)
        if marks < 20 or attendance < 75:
            risk += base_risk(incidents) * 0.20  # 10/50 = 0.2
        elif marks >= 35 and attendance >= 85:
            risk -= base_risk(incidents) * 0.10  # 5/50 = 0.1
        else:
            risk += ((max_marks - min(marks, max_marks)) / max_marks) * 7

    elif incidents == 4:
        risk = base_risk(incidents)
        if marks < 20:
            risk += base_risk(incidents) * 0.125  # 5/40 ≈ 0.125
        else:
            risk += ((max_marks - min(marks, max_marks)) / max_marks) * 5

    elif incidents == 3:
        risk = base_risk(incidents)
        if marks < 20:
            risk += base_risk(incidents) * 0.143  # 5/35 ≈ 0.143
        else:
            risk += ((max_marks - min(marks, max_marks)) / max_marks) * 4

    elif incidents == 2:
        risk = base_risk(incidents)
        if marks < 20:
            risk += base_risk(incidents) * 0.75  # 15/20 = 0.75
        else:
            risk += ((max_marks - min(marks, max_marks)) / max_marks) * 2

    elif incidents == 1:
        risk = base_risk(incidents)
        if marks >= 40:
            risk -= base_risk(incidents) * 0.5  # 5/10 = 0.5
        else:
            risk += ((max_marks - min(marks, max_marks)) / max_marks) * 1

    elif incidents == 0:
        risk = 0
        if marks < 20 and attendance < 75:
            risk += 25
        elif marks < 20 or attendance < 75:
            risk += 10
        elif marks>=20 and attendance>=75 or pending ==0:
            risk = 0
    else:
        risk = 0

    if pending > 0:
        pending_percent = min(1.0, pending / max(1, department_fee))
        risk += pending_percent * 25

    # return float(f"{max(0.0, min(risk, 100.0)):.2f}")
    return float(f"{risk}")
    if incidents>=8:
        return round(sigmoid_cap(risk), 2)

# student = {
#     "incident_count": 2,
#     "avg_internal_marks": 35,
#     "attendance_percentage": 72,
#     "department_fees_amount": 5000,
#     "pending_amount": 1200,
# }

# score = calculate_risk(student)
# print("Risk Score:", score)
