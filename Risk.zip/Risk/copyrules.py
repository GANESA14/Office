def calculate_risk(student: dict) -> int:
    incidents = int(student.get('incident_count', 0))
    attendance = float(student.get('attendance_percentage', 100))
    marks = float(student.get('avg_internal_marks', 50))
    department_fee = float(student.get('department_fees_amount', 0))
    pending = float(student.get('pending_amount', 0))

    # --------------------------------------------------
    # 1. Base risk from incidents
    # --------------------------------------------------
    incident_risk_map = {
        10: 100,
        9: 85,
        8: 75,
        7: 65,
        6: 55,
        5: 50,
        4: 40,
        3: 35,
        2: 20,
        1: 10,
        0: 0
    }

    risk = incident_risk_map.get(incidents, 0)

    # Special handling for incident == 10
    if incidents == 10:
        conditions_met = 0
        if attendance > 90:
            conditions_met += 1
        if marks > 40:
            conditions_met += 1
        if pending == 0:
            conditions_met += 1

        if conditions_met == 3:
            risk -= 10
        elif conditions_met == 2:
            risk -= 5
        elif conditions_met == 1:
            risk -= 2

    # --------------------------------------------------
    # 2. Marks adjustment
    # --------------------------------------------------
    if marks < 10:
        risk += 25
    elif marks < 20:
        risk += 15
    elif marks == 20:
        risk = risk
    elif marks < 30:
        risk += 5
    elif marks >= 40:
        risk -= 10

    # --------------------------------------------------
    # 3. Attendance adjustment (EVEN progression)
    # --------------------------------------------------
    if attendance < 50:
        risk += 20
    elif attendance < 60:
        risk += 15
    elif attendance < 70:
        risk += 10
    elif attendance == 75:
        risk == risk
    elif attendance < 80:
        risk -= 2
    elif attendance < 90:
        risk -= 5
    else:
        risk -= 10

    # --------------------------------------------------
    # 4. Financial adjustment (PERCENTAGE based)
    # --------------------------------------------------
    if department_fee > 0 and pending > 0:
        pending_percent = min(1.0, pending / department_fee)

        max_impact = 20 if risk >= 50 else 10
        fee_impact = round(pending_percent * max_impact)

        if pending > 0:
            risk += fee_impact
    if risk >= 98:
        return max(0, min(risk, 100))
    return max(0, min(round(risk), 100))


student = {
    "incident_count": 8,
    "avg_internal_marks": 18,
    "attendance_percentage": 68,
    "department_fees_amount": 30000,
    "pending_amount": 5000,
}

score = calculate_risk(student)
print("Risk Score:", score)