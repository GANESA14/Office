import pandas as pd
import lightgbm as lgb
import joblib
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# RULES ARE USED ONLY HERE (TEACHING PHASE)
from rules import calculate_risk


# -----------------------------
# CONFIG
# -----------------------------
MAX_MARKS = 50
MODEL_PATH = "risk_model.joblib"
SCHEMA_PATH = "feature_schema.joblib"


# -----------------------------
# 1. Load dataset
# -----------------------------
df = pd.read_csv(
    "Model.csv",
    header=None,
    names=[
        "incident_count",
        "avg_internal_marks",
        "attendance_percentage",
        "department_fees_amount",
        "pending_amount"
    ]
)

print("Dataset loaded:", df.shape)


# -----------------------------
# 2. Feature normalization
# -----------------------------
df["marks"] = (df["marks"] / MAX_MARKS) * 100

print("Marks normalized to percentage (0–100)")


# -----------------------------
# 3. Generate labels using rules
# -----------------------------
def build_student(row):
    return {
        "attendance_percentage": row.attendance_percentage,
        "avg_internal_marks": row.avg_internal_marks,
        "pending_amount": row.pending_amount,
        "department_fees_amount": row.department_fees_amount,
        "incident_count": row.incident_count
    }


df["risk_score"] = [
    calculate_risk(build_student(r))
    for r in df.itertuples(index=False)
]

print("Risk scores generated using rules")


# -----------------------------
# 4. Features & target
# -----------------------------
FEATURE_COLUMNS = [
    "incident_count",
    "avg_internal_marks",
    "attendance_percentage",
    "department_fees_amount",
    "pending_amount"
]

X = df[FEATURE_COLUMNS]
y = df["risk_score"]


# -----------------------------
# 5. Save feature schema
# -----------------------------
schema = {
    "features": FEATURE_COLUMNS,
    "max_marks": MAX_MARKS,
    "version": 1
}

joblib.dump(schema, SCHEMA_PATH)
print("Feature schema saved")


# -----------------------------
# 6. Train-test split
# -----------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)


# -----------------------------
# 7. LightGBM datasets
# -----------------------------
train_data = lgb.Dataset(X_train, label=y_train)
test_data = lgb.Dataset(X_test, label=y_test)


# -----------------------------
# 8. Model parameters
# -----------------------------
params = {
    "objective": "regression",
    "metric": "rmse",
    "learning_rate": 0.05,
    "num_leaves": 15,
    "min_data_in_leaf": 10,
    "feature_fraction": 0.8,
    "bagging_fraction": 0.8,
    "bagging_freq": 5,
    "verbosity": -1
}


# -----------------------------
# 9. Train model
# -----------------------------
model = lgb.train(
    params,
    train_data,
    num_boost_round=300,
    valid_sets=[test_data],
    callbacks=[lgb.early_stopping(30)]
)

print("Model training completed")


# -----------------------------
# 10. Evaluate
# -----------------------------
y_pred = model.predict(X_test)
rmse = mean_squared_error(y_test, y_pred) ** 0.5
print(f"Validation RMSE: {rmse:.4f}")


# -----------------------------
# 11. Save model
# -----------------------------
joblib.dump(model, MODEL_PATH)

print("Model saved as risk_model.joblib")
print("\nTRAINING COMPLETE — rules.py NOT needed in production")
