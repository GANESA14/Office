import joblib
import numpy as np
from rules import calculate_risk

# -----------------------------
# LOAD MODEL & SCHEMA
# -----------------------------
MODEL_PATH = "risk_model.joblib"
SCHEMA_PATH = "feature_schema.joblib"

model = joblib.load(MODEL_PATH)
schema = joblib.load(SCHEMA_PATH)

MAX_MARKS = schema["max_marks"]
FEATURES = schema["features"]

# print("Model & schema loaded successfully")

def validate_inputs(data: dict):
    for key in FEATURES:
        if key not in data:
            raise ValueError(f"Missing feature: {key}")

    if not (0 <= data["avg_internal_marks"] <= MAX_MARKS):
        raise ValueError("Marks out of valid range")

    if not (0 <= data["attendance_percentage"] <= 100):
        raise ValueError("Attendance must be 0–100")

    if data["incident_count"] < 0:
        raise ValueError("Incidents cannot be negative")

    if data["pending_amount"] < 0 or data["department_fees_amount"] < 0:
        raise ValueError("Fee values cannot be negative")


# -----------------------------
# Prediction function
# -----------------------------
def predict_risk(
    incident_count: int,
    avg_internal_marks: float,
    attendance_percentage: float,
    department_fees_amount: float,
    pending_amount: float
) -> float:
    """
    Rule-free ML prediction
    """

    data = {
        "incident_count": incident_count,
        "avg_internal_marks": avg_internal_marks,
        "attendance_percentage": attendance_percentage,
        "department_fees_amount": department_fees_amount,
        "pending_amount": pending_amount
    }

    validate_inputs(data)

    # Normalize marks
    data["avg_internal_marks"] = (data["avg_internal_marks"] / MAX_MARKS) * 100

    features = np.array([[data[f] for f in FEATURES]])

    risk_score = model.predict(features)[0]
    return float(risk_score)


# -----------------------------
# CLI test
# -----------------------------
if __name__ == "__main__":

    student = {
    "incident_count": 2,
    "avg_internal_marks": 35,
    "attendance_percentage": 72,
    "department_fees_amount": 5000,
    "pending_amount": 1200,
}

    risk = predict_risk(**student)
    value_frm_rules= calculate_risk(student)
    print(f"Risk Score By Rules,{value_frm_rules:.2f}")
    print(f"\nPredicted Risk Score by ML: {risk:.2f}")

