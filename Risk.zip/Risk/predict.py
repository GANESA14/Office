import pandas as pd
import joblib
from rules import calculate_risk

# 1️⃣ Load your saved model
model = joblib.load("risk_model.joblib")  # the model you trained

# 2️⃣ Define a new student data (same format as training)
student = {
    "incidents": 3,
    "marks": 42,
    "attendance": 68,
    "department_fee": 30000,
    "pending": 5000
}

# 3️⃣ Predict using ML model
X_new = pd.DataFrame([[
    student["incidents"],
    student["marks"],
    student["attendance"],
    student["department_fee"],
    student["pending"]
]], columns=["incidents","marks","attendance","department_fee","pending"])

predicted_risk = model.predict(X_new)[0]
print("Predicted Risk Score by ML Model:", predicted_risk)

# 4️⃣ Calculate using rules
student_rules = {
    "incident_count": student["incidents"],
    "avg_internal_marks": student["marks"],
    "attendance_percentage": student["attendance"],
    "department_fees_amount": student["department_fee"],
    "pending_amount": student["pending"]
}

rules_risk = calculate_risk(student_rules)
print("Risk Score by Rules:", rules_risk)
