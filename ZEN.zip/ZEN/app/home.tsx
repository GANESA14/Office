import React, { useState, useCallback, useEffect, useRef } from 'react';
import {View,TextInput,FlatList,TouchableOpacity,Text,StyleSheet,Modal,StatusBar,Alert,ActivityIndicator,Image,Animated,Dimensions,ScrollView,Pressable
} from 'react-native';
import { Ionicons, FontAwesome5, Feather, MaterialIcons, MaterialCommunityIcons } from '@expo/vector-icons';
import axios from 'axios';
import debounce from 'lodash.debounce';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { LinearGradient } from 'expo-linear-gradient';
import { Picker } from "@react-native-picker/picker";
import popData from "./popular.json"; 
type NavigationProp = NativeStackNavigationProp<RootStackParamList, 'Index'>;
import { SafeAreaView } from "react-native-safe-area-context";
 
const LOCATIONIQ_API_KEY = 'pk.b2751cfe4d858539b81591e42aa1ce9d';
const { width, height } = Dimensions.get('window');

type Suggestion = {
  place_id: string;
  display_name: string;
};

type BusRoute = {
  uniqueId: string;
  startPoint: string;
  endPoint: string;
  duration: string;
  fare: string;
  busNumber: string;
};

type RootStackParamList = {
  Index: undefined;
  Data: undefined;
  Bus: { datastoBus: string[] };
  Add: undefined; 
  LoginFlow: undefined; 
  Live:{ datastoBus: string[] };
};

const formatDayText = (day: string) => {
  return day.substring(0, 1);
};

const SearchInput = () => {
  const navigation = useNavigation<NavigationProp>();
  const fadeAnim = useState(new Animated.Value(0))[0];
  const slideAnim = useState(new Animated.Value(100))[0];
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const rotateAnim = useRef(new Animated.Value(0)).current;
  const [Live,SetLive]=useState('Live');
  const [fromQuery, setFromQuery] = useState('');
  const [toQuery, setToQuery] = useState('');
  const [fromSuggestions, setFromSuggestions] = useState<Suggestion[]>([]);
  const [toSuggestions, setToSuggestions] = useState<Suggestion[]>([]);
  const [error, setError] = useState('');
  const [activeInput, setActiveInput] = useState<'from' | 'to' | null>(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedFromText, setSelectedFromText] = useState('');
  const [selectedToText, setSelectedToText] = useState('');
  const [filteredRoutes, setFilteredRoutes] = useState<BusRoute[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [recentSearches] = useState<string[]>(['Gandhipuram', 'Ukkadam', 'Singanallur', 'Saravanampatti']);
  const [showDistrictPicker, setShowDistrictPicker] = useState(false);
  const weekDays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const currentDayIndex = new Date().getDay();
    const [selectedDay, setSelectedDay] = useState(weekDays[currentDayIndex]);
  const [selectedDistrict, setSelectedDistrict] = useState('');
  const [busStoped, setBusStoped] = useState<string[]>([]);
  const [areas, setAreas] = useState<string[]>([]);
  

const handleDistrictChange = (districtName: string) => {
  setSelectedDistrict(districtName);
  const selected = popData.TamilNadu.districts.find((d) => d.name === districtName);
  if (selected) {
    setBusStoped(selected.popular_bus_stops);
    setAreas(selected.areas);
  }
};
useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.1,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        })
      ])
    ).start();
    
    // Rotate animation for swap button
    Animated.loop(
      Animated.sequence([
        Animated.timing(rotateAnim, {
          toValue: 1,
          duration: 1500,
          useNativeDriver: true
        }),
        Animated.timing(rotateAnim, {
          toValue: 0,
          duration: 1500,
          useNativeDriver: true
        })
      ])
    ).start();
  }, []);

  const spin = rotateAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '180deg']
  });

  // Main animations
  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      })
    ]).start();
  }, []);

  const fetchSuggestions = useCallback(
    debounce(async (text: string, setSuggestions: React.Dispatch<React.SetStateAction<Suggestion[]>>) => {
      if (text.length > 2) {
        setIsLoading(true);
        try {
          const response = await axios.get(
            `https://api.locationiq.com/v1/autocomplete.php?key=${LOCATIONIQ_API_KEY}&q=${text}&format=json`
          );
          setSuggestions(response.data || []);
        } catch (err) {
          setError('Failed to fetch location suggestions');
          Alert.alert('Error', 'Unable to fetch location suggestions. Please try again.');
        } finally {
          setIsLoading(false);
        }
      } else {
        setSuggestions([]);
      }
    }, 300),
    []
  );

  const handleFromInputChange = (text: string) => {
    setFromQuery(text);
    setError('');
    fetchSuggestions(text, setFromSuggestions);
  };

  const handleToInputChange = (text: string) => {
    setToQuery(text);
    setError('');
    fetchSuggestions(text, setToSuggestions);
  };

  const handleSelect = (place: Suggestion) => {
    if (activeInput === 'from') {
      setSelectedFromText(place.display_name);
      setFromQuery('');
    } else if (activeInput === 'to') {
      setSelectedToText(place.display_name);
      setToQuery('');
    }
    setModalVisible(false);
  };

  const openModal = (input: 'from' | 'to') => {
    setActiveInput(input);
    setModalVisible(true);
    if (input === 'from') {
      fetchSuggestions(fromQuery, setFromSuggestions);
    } else {
      fetchSuggestions(toQuery, setToSuggestions);
    }
  };

  const handleSwapLocations = () => {
    const tempFrom = selectedFromText;
    setSelectedFromText(selectedToText);
    setSelectedToText(tempFrom);
    
    // Add swap animation
    Animated.sequence([
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 200,
        useNativeDriver: true
      }),
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 400,
        useNativeDriver: true
      })
    ]).start();
  };

  const scaleXAnim = useRef(new Animated.Value(0)).current;
  const textOpacity = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.sequence([
      Animated.timing(scaleXAnim, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }),
      Animated.timing(textOpacity, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const navigateToAdd = () => {
    navigation.navigate('LoginFlow');
  };
  
  const tamilNaduDistricts = [
    "Ariyalur", "Chengalpattu", "Chennai", "Coimbatore", "Cuddalore", 
    "Dharmapuri", "Dindigul", "Erode", "Kallakurichi", "Kancheepuram", 
    "Kanniyakumari", "Karur", "Krishnagiri", "Madurai", "Mayiladuthurai", 
    "Nagapattinam", "Namakkal", "Nilgiris", "Perambalur", "Pudukkottai", 
    "Ramanathapuram", "Ranipet", "Salem", "Sivaganga", "Tenkasi", 
    "Thanjavur", "Theni", "Thoothukudi", "Tiruchirappalli", "Tirunelveli", 
    "Tirupattur", "Tiruppur", "Tiruvallur", "Tiruvannamalai", "Tiruvarur", 
    "Vellore", "Viluppuram", "Virudhunagar"
  ];
  
  const sample: string[] = []; 
  const handleSearch = () => {
    if (!selectedFromText || !selectedToText || !selectedDistrict) {
      Alert.alert('Error', 'Please select source, destination, and district');
      return;
    }
  
    const dataToBus = [
      selectedFromText.split(',')[0],
      selectedToText.split(',')[0],
      selectedFromText,
      selectedToText,
      selectedDistrict
    ];
  
    navigation.navigate(isToggleOn ? 'Live' : 'Bus', { datastoBus: dataToBus });
  };


  const renderSuggestions = () => {
    const suggestions = activeInput === 'from' ? fromSuggestions : toSuggestions;
    const combinedData = busStoped; 

    return (
      <FlatList
        data={suggestions}
        keyExtractor={(item, index) => `${item.place_id}-${index}`}
        renderItem={({ item }) => (
          <TouchableOpacity 
            style={styles.suggestionItem} 
            onPress={() => handleSelect(item)}
          >
            <LinearGradient
              colors={['#5345D9', '#7A5FFF']}
              style={styles.suggestionIcon}
            >
              <Ionicons name="location-outline" size={16} color="#FFF" />
            </LinearGradient>
            <Text style={styles.suggestionText} numberOfLines={2}>
              {item.display_name}
            </Text>
          </TouchableOpacity>
        )}
        ListHeaderComponent={
          <View style={styles.recentSearchesContainer}>
            <Text style={styles.recentSearchesTitle}>Popular Places</Text>
            <View style={styles.recentSearchesList}>
         {selectedDistrict && (
                 <View>
                   <FlatList 
                     data={combinedData} numColumns={2} 
                     keyExtractor={(item, index) => index.toString()}
                     renderItem={({ item }) => <TouchableOpacity  
                     style={styles.recentSearchItem}
                     onPress={() => handleSelect({ 
                       place_id: `place-${item}`, 
                       display_name: item 
                     })}>
                     <Text style={styles.recentSearchText}>{item}</Text>
                     </TouchableOpacity>}
                   />
                   
                 </View>
               )}
            </View>
          </View>
        }
        ListEmptyComponent={
          isLoading ? (
            <View style={styles.loaderContainer}>
              <ActivityIndicator size="large" color="#7A5FFF" />
              <Text style={styles.messageText}>Loading Places...</Text>
            </View>
          ) : (
            <View style={styles.emptyContainer}>
              <Ionicons name="search-outline" size={48} color="#5345D9" />
              <Text style={styles.messageText}>Type to search locations</Text>
            </View>
          )
        }
      />
    );
  };
   const [isToggleOn, setIsToggleOn] = useState(false);
   const toggleAnimatedValue = useRef(new Animated.Value(0)).current;
 
   useEffect(() => {
     Animated.timing(toggleAnimatedValue, {
       toValue: isToggleOn ? 1 : 0,
       duration: 150,
       useNativeDriver: false,
     }).start();
   }, [isToggleOn]);
 
   const toggleBackgroundColor = toggleAnimatedValue.interpolate({
     inputRange: [0, 1],
     outputRange: ["#0F0F28", "#05f569"],
   });
 
   const toggleTranslateX = toggleAnimatedValue.interpolate({
     inputRange: [0, 1],
     outputRange: [0, 30],
   });
   return (
    <SafeAreaView style={styles.container}>
      <StatusBar backgroundColor="#070718" barStyle="light-content" />
      
      <LinearGradient
        colors={['#1F1F3F', '#0F0F28']}
        style={styles.background}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      />
      
      <Animated.View>
        <LinearGradient
          colors={['#7A5FFF', '#5345D9']}
          style={styles.header}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
        >
          <View style={styles.headerContent}>
            <View>
              <Text style={styles.headerTitle}>Local Bus</Text>
              <Text style={styles.headerSubtitle}>Find the perfect route</Text>
            </View>
            <View style={styles.logoContainer}>
              <Ionicons name="bus" size={28} color="#FFF" />
            </View>
          </View>
        </LinearGradient>
      </Animated.View>
      
          <ScrollView showsVerticalScrollIndicator={false} style={{ flex: 1 }}>
        <Animated.View 
          style={[
            styles.searchCardContainer,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }]
            }
          ]}
        >
          <LinearGradient
            colors={['#1D1D42', '#14142B']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.searchCard}
          >
            
          <View style={styles.toggleContainer}>
            <Pressable onPress={() => setIsToggleOn(!isToggleOn)} style={styles.toggleSwitchContainer}>
              <Animated.View style={[styles.toggleSwitch, { transform: [{ translateX: toggleTranslateX }], backgroundColor: toggleBackgroundColor }]} >
              </Animated.View>
            </Pressable>
            <Text style={styles.toggleStatusText}>{isToggleOn ? "Live Bus" : "Schedule"}</Text>
          </View>
            <View style={styles.inputContainer}>
              <TouchableOpacity 
                onPress={() => openModal('from')} 
                style={styles.inputBox}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={['#7A5FFF', '#5345D9']}
                  style={styles.inputIconContainer}
                >
                  <Ionicons name="locate" size={18} color="#FFF" />
                </LinearGradient>
                <Text style={[styles.inputText, !selectedFromText && styles.placeholderText]}>
                  {selectedFromText || 'From'}
                </Text>
                {selectedFromText ? (
                  <TouchableOpacity 
                    onPress={() => setSelectedFromText('')} 
                    style={styles.clearButton}
                  >
                    <Feather name="x" size={16} color="#A9A6FF" />
                  </TouchableOpacity>
                ) : null}
              </TouchableOpacity>

              <Animated.View style={{
                position: 'absolute',
                right: 0,
                zIndex: 10,
                top: '50%',
                marginTop: -25
              }}>
                <TouchableOpacity onPress={handleSwapLocations} style={styles.swapButton}>
                  <LinearGradient
                    colors={['#7A5FFF', '#5345D9']}
                    style={styles.swapButtonGradient}
                  >
                    <Ionicons name="swap-vertical" size={22} color="#FFF" />
                  </LinearGradient>
                </TouchableOpacity>
              </Animated.View>

              <TouchableOpacity 
                onPress={() => openModal('to')} 
                style={styles.inputBox}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={['#4CAF50', '#2E7D32']}
                  style={styles.inputIconContainer}
                >
                  <Ionicons name="location" size={18} color="#FFF" />
                </LinearGradient>
                <Text style={[styles.inputText, !selectedToText && styles.placeholderText]}>
                  {selectedToText || 'To'}
                </Text>
                {selectedToText ? (
                  <TouchableOpacity 
                    onPress={() => setSelectedToText('')} 
                    style={styles.clearButton}
                  >
                    <Feather name="x" size={16} color="#A9A6FF" />
                  </TouchableOpacity>
                ) : null}
              </TouchableOpacity>
            </View>
            <View style={styles.wrapper}>
      {weekDays.map((day) => (
        <Pressable
          key={day}
          style={[styles.box, selectedDay === day && styles.activeBox]}
          onPress={() => setSelectedDay(day)}
        >
          <Text style={[styles.label, selectedDay === day && styles.activeLabel]}>
            {formatDayText(day)}
          </Text>
        </Pressable>
      ))}
    </View>
            <View style={styles.pickerContainer}>
  <Picker
    selectedValue={selectedDistrict}
    onValueChange={handleDistrictChange}
    style={styles.picker}
    dropdownIconColor="#A9A6FF"
  >
    <Picker.Item label="Select District" value="" />
    {tamilNaduDistricts.map((district, index) => (
      <Picker.Item key={index} label={district} value={district} />
    ))}
  </Picker>
</View>

            {showDistrictPicker && (
              <View style={styles.pickerContainer}>
                <LinearGradient
                  colors={['#252544', '#1A1A36']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={{ borderRadius: 12 }}
                >
                  <ScrollView style={styles.districtScrollView} showsVerticalScrollIndicator={false}>
                    {tamilNaduDistricts.map((district, index) => (
                      <TouchableOpacity
                        key={index}
                        style={[
                          styles.districtOption,
                          selectedDistrict === district && styles.selectedDistrictOption
                        ]}
                        onPress={() => {
                          setSelectedDistrict(district);
                          setShowDistrictPicker(false);
                        }}
                      >
                        <Text style={[
                          styles.districtOptionText,
                          selectedDistrict === district && styles.selectedDistrictOptionText
                        ]}>
                          {district}
                        </Text>
                        {selectedDistrict === district && (
                          <Ionicons name="checkmark-circle" size={18} color="#7A5FFF" />
                        )}
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                </LinearGradient>
              </View>
            )}
            <TouchableOpacity 
              style={[
                styles.searchButton, 
                (!selectedFromText || !selectedToText || !selectedDistrict) && styles.searchButtonDisabled
              ]}
              onPress={handleSearch}
              disabled={!selectedFromText || !selectedToText || !selectedDistrict}
              activeOpacity={0.8}
            >
              <LinearGradient
                colors={(!selectedFromText || !selectedToText || !selectedDistrict) ? 
                  ['#333355', '#252544'] : ['#7A5FFF', '#5345D9']}
                style={styles.searchButtonGradient}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
              >
                <Ionicons name="search" size={20} color="#FFF" style={{ marginRight: 8 }} />
                <Text style={styles.searchButtonText}>Search Bus</Text>
              </LinearGradient>
            </TouchableOpacity>
          </LinearGradient>
        </Animated.View>

        <View style={styles.screen}>
          <TouchableOpacity 
            onPress={navigateToAdd} 
            activeOpacity={0.8} 
            style={styles.addBusButton}
          >
            <LinearGradient colors={['#5345D9', '#7A5FFF']} style={styles.addBusButtonGradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
              <Animated.View style={{ transform: [{ scaleX: scaleXAnim }] }}>
                <Ionicons name="add-circle-outline" size={22} color="#FFF" style={{ marginRight: 8 }} />
              </Animated.View>
              <Animated.Text style={[styles.addBusButtonText, { opacity: textOpacity }]}>
                Add New Route
              </Animated.Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </ScrollView>

      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setModalVisible(false)}
      >
        <SafeAreaView style={styles.modalContainer}>
          <LinearGradient
            colors={['#0F0F28', '#070718']}
            style={{ flex: 1 }}
          >
            <View style={styles.modalHeader}>
              <TouchableOpacity 
                onPress={() => setModalVisible(false)}
                style={styles.closeButton}
              >
                <Ionicons name="arrow-back" size={24} color="#7A5FFF" />
              </TouchableOpacity>
              <Text style={styles.modalTitle}>
                {activeInput === 'from' ? 'Select Starting Point' : 'Select Destination'}
              </Text>
              <View style={{ width: 40 }} />
            </View>

            <LinearGradient
              colors={['#1D1D42', '#14142B']}
              style={styles.searchInputContainer}
            >
              <Ionicons name="search" size={20} color="#A9A6FF" />
              <TextInput
                style={styles.modalInput}
                placeholder="Search Location"
                value={activeInput === 'from' ? fromQuery : toQuery}
                onChangeText={activeInput === 'from' ? handleFromInputChange : handleToInputChange}
                autoFocus
                placeholderTextColor="#6E6CA8"
                selectionColor="#7A5FFF"
              />
              {(activeInput === 'from' ? fromQuery : toQuery) ? (
                <TouchableOpacity 
                  onPress={() => activeInput === 'from' ? setFromQuery('') : setToQuery('')}
                >
                  <Ionicons name="close-circle" size={20} color="#A9A6FF" />
                </TouchableOpacity>
              ) : null}
            </LinearGradient>
            
            {renderSuggestions()}
          </LinearGradient>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#070718',
  },
  background: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    height: height,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom:15,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    elevation: 20,
    shadowColor: '#5345D9',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.4,
    shadowRadius: 20,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  logoContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    color: '#FFF',
    fontSize: 32,
    fontWeight: 'bold',
    letterSpacing: 0.5,
    marginBottom: 4,
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 5,
  },
  headerSubtitle: {
    color: 'rgba(255, 255, 255, 0.8)',
    fontSize: 16,
    letterSpacing: 0.2,
  },
  searchCardContainer: {
    marginTop: 40,
    zIndex: 10,
    paddingHorizontal: 16,
  },
  searchCard: {
    borderRadius: 24,
    padding: 16,
    elevation: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    borderWidth: 1,
    borderColor: '#2A2A50',
  },
  inputContainer: {
    gap: 20,
    marginBottom: 5,
  },
  inputBox: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#1A1A36',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#2A2A50',
  },
  inputIconContainer: {
    padding: 10,
    borderRadius: 10,
    marginRight: 12,
    shadowColor: '#5345D9',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
    elevation: 8,
  },
  inputText: {
    flex: 1,
    color: '#E6E6FF',
    fontSize: 16,
    fontWeight: '500',
  },
  placeholderText: {
    color: '#6E6CA8',
  },
  clearButton: {
    padding: 6,
  },
  swapButton: {
    elevation: 20,
    shadowColor: '#5345D9',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.7,
    shadowRadius: 12,
    zIndex: 2,
    borderRadius: 30,
    borderWidth: 3,
    borderColor: '#14142B',
  },
  swapButtonGradient: {
    borderRadius: 25,
    width: 50,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',},
    searchButton: {
      borderRadius: 16,
      overflow: 'hidden',
    },
    searchButtonDisabled: {
      opacity: 0.7,
    },
    searchButtonGradient: {
      paddingVertical: 16,
      alignItems: 'center',
      justifyContent: 'center',
      flexDirection: 'row',
    },
    searchButtonText: {
      color: '#FFF',
      fontSize: 16,
      fontWeight: 'bold',
      letterSpacing: 0.5,
    },
    screen: {
      flex: 1,
      padding: 16,
    },
    sectionHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 16,
      marginTop: 8,
    },
    sectionTitle: {
      color: '#E6E6FF',
      fontSize: 20,
      fontWeight: 'bold',
    },
    seeAllText: {
      color: '#7A5FFF',
      fontSize: 14,
      fontWeight: '600',
    },
    routeCard: {
      marginBottom: 16,
      borderRadius: 20,
      padding: 16,
      elevation: 8,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.3,
      shadowRadius: 12,
      borderWidth: 1,
      borderColor: '#2A2A50',
    },
    glowContainer: {
      position: 'absolute',
      top: -10,
      right: 20,
      shadowColor: '#5345D9',
      shadowOffset: { width: 0, height: 0 },
      shadowOpacity: 0.8,
      shadowRadius: 10,
      elevation: 10,
    },
    routeBusNumber: {
      paddingHorizontal: 12,
      paddingVertical: 6,
      borderRadius: 10,
      elevation: 8,
    },
    busNumberText: {
      color: 'white',
      fontWeight: 'bold',
      fontSize: 16,
    },
    routeDetails: {
      flexDirection: 'row',
      marginTop: 10,
    },
    routeStations: {
      width: 24,
      alignItems: 'center',
      marginRight: 10,
      height: '100%',
    },
    stationDot: {
      width: 12,
      height: 12,
      borderRadius: 6,
      backgroundColor: '#7A5FFF',
    },
    routeLine: {
      flex: 1,
      width: 3,
      alignSelf: 'center',
      marginVertical: 6,
    },
    routeLineGradient: {
      flex: 1,
      width: 3,
    },
    routeInfo: {
      flex: 1,
      justifyContent: 'space-between',
    },
    stationText: {
      color: '#E6E6FF',
      fontSize: 16,
      fontWeight: '600',
      marginVertical: 4,
    },
    routeMiddleInfo: {
      marginVertical: 8,
    },
    routeMiddleInfoGradient: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 8,
      borderRadius: 10,
    },
    routeDuration: {
      color: '#A9A6FF',
      fontSize: 14,
    },
    routeSeparator: {
      width: 1,
      height: 16,
      backgroundColor: '#3F3D70',
      marginHorizontal: 10,
    },
    routeFare: {
      color: '#A9A6FF',
      fontSize: 14,
    },
    modalContainer: {
      flex: 1,
      backgroundColor: '#070718',
    },
    modalHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: 16,
    },
    closeButton: {
      padding: 8,
    },
    modalTitle: {
      color: '#E6E6FF',
      fontSize: 18,
      fontWeight: 'bold',
      letterSpacing: 0.3,
    },
    searchInputContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      margin: 16,
      paddingHorizontal: 16,
      paddingVertical: 12,
      backgroundColor: '#1A1A36',
      borderRadius: 16,
      borderWidth: 1,
      borderColor: '#2A2A50',
    },
    modalInput: {
      flex: 1,
      color: '#E6E6FF',
      fontSize: 16,
      marginLeft: 8,
      paddingVertical: 8,
    },
    suggestionItem: {
      flexDirection: 'row',
      alignItems: 'center',
      padding: 16,
      marginHorizontal: 16,
      marginVertical: 4,
      backgroundColor: '#1A1A36',
      borderRadius: 12,
      borderWidth: 1,
      borderColor: '#2A2A50',
    },
    suggestionIcon: {
      padding: 8,
      borderRadius: 8,
      marginRight: 12,
    },
    suggestionText: {
      color: '#E6E6FF',
      fontSize: 14,
      flex: 1,
    },
    loaderContainer: {
      padding: 20,
      alignItems: 'center',
      justifyContent: 'center',
    },
    messageText: {
      color: '#A9A6FF',
      marginTop: 16,
      fontSize: 16,
      textAlign: 'center',
    },
    emptyContainer: {
      padding: 40,
      alignItems: 'center',
      justifyContent: 'center',
    },
    recentSearchesContainer: {
      padding: 16,
    },
    recentSearchesTitle: {
      color: '#E6E6FF',
      fontSize: 16,
      fontWeight: '600',
      marginBottom: 12,
    },
    recentSearchesList: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      gap: 8,
    },
    recentSearchItem: {
      padding:8,
      borderRadius: 20,
      borderWidth: 1,
      borderColor: '#2A2A50',backgroundColor:'#1A1A36',
      margin:5,width:'auto'
    },picker: {
      color: '#E6E6FF',
      fontSize: 16,backgroundColor:'#1A1A36',
      padding: 5,
    },
    recentSearchText: {
      color: '#A9A6FF',
      fontSize: 14,
    },
    districtSelector: {
      marginBottom: 20,
    },
    districtSelectorGradient: {
      borderRadius: 16,
      padding: 16,
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      borderWidth: 1,
      borderColor: '#2A2A50',
    },
    districtText: {
      color: '#E6E6FF',
      fontSize: 16,
      fontWeight: '500',
    },
    pickerContainer: {
      marginBottom: 10,marginTop:10,
      overflow: 'hidden',
borderRadius: 16,
      borderWidth: 1,
      borderColor: '#2A2A50',
    },
    districtScrollView: {
      maxHeight: 200,
    },
    districtOption: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: 16,
      borderBottomWidth: 1,
      borderBottomColor: '#2A2A50',
    },
    selectedDistrictOption: {
      backgroundColor: 'rgba(122, 95, 255, 0.15)',
    },
    districtOptionText: {
      color: '#A9A6FF',
      fontSize: 16,
    },
    selectedDistrictOptionText: {
      color: '#E6E6FF',
      fontWeight: '600',
    },
    addBusButton: {
      marginTop: 16,
      marginBottom: 24,
      borderRadius: 16,
      overflow: 'hidden',
      elevation: 8,
      shadowColor: '#2E7D32',
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.3,
      shadowRadius: 12,
    },
    addBusButtonGradient: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      paddingVertical: 16,
    },
    addBusButtonText: {
      color: '#FFF',
      fontSize: 16,
      fontWeight: 'bold',
      letterSpacing: 0.5,
    }, wrapper: {
      flexDirection: "row",
      justifyContent: "space-around",
      padding: 10,
      flex: 1,
      alignItems: "center",
      borderRadius: 16,
      borderWidth: 1,
      borderColor: '#2A2A50',marginTop:10
    },
    box: {
      borderWidth: 2,padding:10,
      borderColor: "#5345D9",
      alignItems: "center",
      justifyContent: "center",
      borderRadius: 8,
    },
    activeBox: {
      backgroundColor: "#7A5FFF",
      borderColor: "#7A5FFF",
    },
    label: {
      fontSize: 14,
      fontWeight: "bold",
      color: "#AAA",
    },
    activeLabel: {
      color: "#FFF",
    }, toggleContainer: {
      // flex: 1,
      justifyContent: 'flex-end',
      alignItems: 'flex-end',
    },
    toggleStatusText: {
      fontSize: 16,
      fontWeight: "bold",color:'white'
      // marginBottom: 10,
    },
    toggleSwitchContainer: {
      width: 60,
      height: 30,
      borderRadius: 15,
      backgroundColor: "#5345D9",
      justifyContent: "center",
      padding: 2,
    },
    toggleSwitch: {
      width: 26,
      height: 26,
      borderRadius: 13,
    },
  });
  
  export default SearchInput;