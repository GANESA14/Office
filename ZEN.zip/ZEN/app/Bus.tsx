import { MaterialIcons } from '@expo/vector-icons';
import { useRoute } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { doc, getDoc } from "firebase/firestore";
import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator, FlatList,
  Modal,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet, Text,
  TouchableOpacity,
  View
} from 'react-native';
import WebView, { WebViewMessageEvent } from 'react-native-webview';
import { db } from "./firebaseConfig";

type Stop = { name: string; timing: string; };
type Bus = {
  name: string; routeNo: string; source: string; sourceTiming: string;
  destination: string; destinationTiming: string; stops: Stop[];
};
type RouteParams = { datastoBus?: string[]; };
interface BusStop { timeSlot: string; stopName: string; arrivalTime: string; }

export default function BusRouteApp() {
  const [mapUrl, setMapUrl] = useState<string | null>(null);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [mapLoading, setMapLoading] = useState(true);

  const route = useRoute<any>();
  const { datastoBus = [] } = route.params || {};

  const [busRoutes, setBusRoutes] = useState<string[]>([]);
  const [selectedRoute, setSelectedRoute] = useState<string | null>(null);
  const [buses, setBuses] = useState<Bus[]>([]);
  const [filteredRoutes, setFilteredRoutes] = useState<string[]>([]);
  const [partialMatchInfo, setPartialMatchInfo] = useState<{ [key: string]: { sourceMatch: boolean, destMatch: boolean } }>({});

  // -----------------------
  // Fetch bus routes safely
  // -----------------------
  const fetchBusRoutes = async () => {
    if (!datastoBus || datastoBus.length < 5) {
      console.warn("datastoBus incomplete, cannot fetch routes:", datastoBus);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    try {
      const docRef = doc(db, "Read", datastoBus[4]);
      const docSnap = await getDoc(docRef);
      if (!docSnap.exists()) {
        console.warn("No bus routes document found for:", datastoBus[4]);
        setIsLoading(false);
        return;
      }

      const routes = docSnap.data().Bus || [];
      setBusRoutes(routes);

      if (datastoBus.length > 3) {
        await filterRoutesBySourceAndDestination(routes);
      } else {
        setFilteredRoutes(routes);
      }
    } catch (error) {
      console.error("Error fetching bus routes:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // -----------------------
  // Filter routes with partial matches
  // -----------------------
  const filterRoutesBySourceAndDestination = async (routes: string[]) => {
    const source = datastoBus[2]?.toLowerCase() || '';
    const destination = datastoBus[3]?.toLowerCase() || '';
    const filteredResults: string[] = [];
    const partialMatches: { [key: string]: { sourceMatch: boolean; destMatch: boolean } } = {};
    const sourceWords = source.split(/\s+/).filter(w => w.length > 2);
    const destWords = destination.split(/\s+/).filter(w => w.length > 2);

    try {
      const routeDocs = await Promise.all(
        routes.map(async routeNo => {
          const docRef = doc(db, "Read", datastoBus[4], routeNo, "data");
          return getDoc(docRef).then(docSnap => ({ routeNo, docSnap }));
        })
      );

      for (const { routeNo, docSnap } of routeDocs) {
        if (!docSnap.exists()) continue;
        const data = docSnap.data();
        let busStops: string[] = [];

        for (const timeSlot in data) {
          if (Object.prototype.hasOwnProperty.call(data, timeSlot)) {
            busStops.push(...Object.keys(data[timeSlot]));
          }
        }

        const uniqueStops = Array.from(new Set(busStops.map(s => s.toLowerCase())));
        const sourceIndex = uniqueStops.findIndex(s => s.includes(source));
        const destIndex = uniqueStops.findIndex(s => s.includes(destination));

        if (sourceIndex !== -1 && destIndex !== -1 && sourceIndex < destIndex) {
          filteredResults.push(routeNo);
          partialMatches[routeNo] = { sourceMatch: true, destMatch: true };
          continue;
        }

        const hasPartialSource = uniqueStops.some(stop =>
          sourceWords.every(word => stop.includes(word))
        );
        const hasPartialDest = uniqueStops.some(stop =>
          destWords.every(word => stop.includes(word))
        );

        if (hasPartialSource && hasPartialDest) {
          filteredResults.push(routeNo);
          partialMatches[routeNo] = { sourceMatch: hasPartialSource, destMatch: hasPartialDest };
        }
      }

      setFilteredRoutes(filteredResults);
      setPartialMatchInfo(partialMatches);
    } catch (error) {
      console.error("Error filtering routes:", error);
      setFilteredRoutes([]);
    }
  };

  // -----------------------
  // Fetch bus details
  // -----------------------
  const fetchBusDetails = async (route: string) => {
    try {
      setIsLoading(true);
      const docRef = doc(db, "Read", datastoBus[4], route, "data");
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        setBuses([]);
        console.warn("No bus details found for route:", route);
        return;
      }

      const data = docSnap.data();
      const busStops: BusStop[] = [];

      for (const timeSlot in data) {
        if (Object.prototype.hasOwnProperty.call(data, timeSlot)) {
          for (const stop in data[timeSlot]) {
            busStops.push({ timeSlot, stopName: stop, arrivalTime: data[timeSlot][stop] });
          }
        }
      }

      busStops.sort((a, b) => convertTimeTo24Hour(a.arrivalTime) - convertTimeTo24Hour(b.arrivalTime));

      if (busStops.length > 0) {
        const stopsArray: Stop[] = busStops.slice(1, -1).map(stop => ({
          name: stop.stopName,
          timing: formatTime(stop.arrivalTime)
        }));

        setBuses([{
          name: `Bus ${route}`,
          routeNo: route,
          source: busStops[0].stopName,
          sourceTiming: formatTime(busStops[0].arrivalTime),
          destination: busStops[busStops.length - 1].stopName,
          destinationTiming: formatTime(busStops[busStops.length - 1].arrivalTime),
          stops: stopsArray
        }]);
      }
    } catch (error) {
      console.error("Error fetching bus details:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const convertTimeTo24Hour = (time: string) => {
    const [hours, minutes] = time.split(".").map(Number);
    return hours * 60 + (minutes || 0);
  };
  const formatTime = (timeStr: string) => {
    const [hourStr, minuteStr] = timeStr.split(".");
    const hour = parseInt(hourStr);
    const minute = minuteStr ? parseInt(minuteStr) : 0;
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const hour12 = hour % 12 || 12;
    return `${hour12}:${minute < 10 ? '0' : ''}${minute} ${ampm}`;
  };

  useEffect(() => { fetchBusRoutes(); }, []);
  useEffect(() => { if (selectedRoute) fetchBusDetails(selectedRoute); }, [selectedRoute]);

  // -----------------------
  // WebView map handling
  // -----------------------
  const handleBusSelection = (bus: Bus) => {
    const { source, destination, stops } = bus;
    if (!source || !destination || stops.length === 0) return;

    const waypoints = [source, ...stops.map(s => s.name), destination];
    const apiKey = "pk.b2751cfe4d858539b81591e42aa1ce9d";
    setMapUrl(generateWebViewContent(waypoints, apiKey));
    setIsModalVisible(true);
    setMapLoading(true);
  };

  const generateWebViewContent = (waypoints: string[], apiKey: string) => {
    return `...`; // Keep your existing HTML/JS for Leaflet map
  };

  const handleMessage = (event: WebViewMessageEvent) => {
    if (event.nativeEvent.data === 'mapLoaded') setMapLoading(false);
  };

  // -----------------------
  // Render
  // -----------------------
  const renderBusRouteItem = ({ item }: { item: string }) => {
    const isPartial = partialMatchInfo[item] && (!partialMatchInfo[item].sourceMatch || !partialMatchInfo[item].destMatch);
    return (
      <TouchableOpacity
        style={[styles.busRouteItem, selectedRoute === item && styles.selectedRouteItem, isPartial && styles.partialMatchItem]}
        onPress={() => setSelectedRoute(item)}
      >
        <Text style={[styles.busRouteText, selectedRoute === item && { color: '#fff' }, isPartial && { color: selectedRoute === item ? '#fff' : '#d76b00' }]}>{item}</Text>
        {isPartial && <Text style={[styles.partialMatchText, selectedRoute === item && { color: '#fff' }]}>Partial Match</Text>}
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar backgroundColor="#070718" barStyle="light-content" />
      <LinearGradient colors={['#7A5FFF', '#5345D9']} style={styles.header}>
        {datastoBus.length >= 5 ? (
          <>
            <Text style={styles.headerTitle}>Bus Routes in {datastoBus[4]}</Text>
            <Text style={styles.headerSubtitle}>{datastoBus[0]} to {datastoBus[1]}</Text>
          </>
        ) : (
          <Text style={[styles.headerTitle, { fontSize: 18 }]}>No bus search data provided</Text>
        )}
      </LinearGradient>

      <View style={styles.routesContainer}>
        {filteredRoutes.length > 0 ? (
          <>
            <FlatList
              data={filteredRoutes}
              renderItem={renderBusRouteItem}
              keyExtractor={item => item}
              horizontal
              showsHorizontalScrollIndicator={false}
              style={styles.routesList}
            />
            <Text style={styles.matchLegend}><MaterialIcons name="info-outline" size={14} color="#d76b00" /> Orange indicates partial word matches</Text>
          </>
        ) : (
          <Text style={styles.noRoutesText}>
            {datastoBus.length < 5 ? "Please provide valid bus search data." : "No routes available for this section."}
          </Text>
        )}
      </View>

      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        {isLoading && selectedRoute ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#1a73e8" />
            <Text style={styles.loadingText}>Loading bus details...</Text>
          </View>
        ) : (
          buses.map(bus => (
            <View key={bus.routeNo} style={styles.busBox}>
              <View style={styles.busHeader}>
                <View>
                  <Text style={styles.busName}>{bus.name}</Text>
                  <Text style={styles.routeNo}>Route {bus.routeNo}</Text>
                  {partialMatchInfo[bus.routeNo] && (!partialMatchInfo[bus.routeNo].sourceMatch || !partialMatchInfo[bus.routeNo].destMatch) &&
                    <Text style={styles.partialMatchAlert}><MaterialIcons name="info-outline" size={14} color="#d76b00" /> Partial match</Text>
                  }
                </View>
                <MaterialIcons name="directions-bus" size={24} color="#1a73e8" />
              </View>

              {/* Render stops */}
              <View style={styles.routeContainer}>
                <View style={styles.routeEndpoint}>
                  <MaterialIcons name="radio-button-checked" size={20} color="#1a73e8" />
                  <View style={styles.routeTextContainer}>
                    <Text style={styles.routeText}>{bus.source}</Text>
                    <Text style={styles.routeLabel}>{bus.sourceTiming}</Text>
                  </View>
                </View>
                {bus.stops.map((stop, i) => (
                  <View key={i} style={styles.routeStop}>
                    <View style={styles.stopLine} />
                    <MaterialIcons name="fiber-manual-record" size={16} color="#5f6368" />
                    <View style={styles.routeTextContainer}>
                      <Text style={styles.stopText}>{stop.name}</Text>
                      <Text style={styles.timingText}>{stop.timing}</Text>
                    </View>
                  </View>
                ))}
                <View style={styles.routeEndpoint}>
                  <MaterialIcons name="place" size={20} color="#ea4335" />
                  <View style={styles.routeTextContainer}>
                    <Text style={styles.routeText}>{bus.destination}</Text>
                    <Text style={styles.routeLabel}>{bus.destinationTiming}</Text>
                  </View>
                </View>
              </View>

              <TouchableOpacity onPress={() => handleBusSelection(bus)} style={styles.viewRouteButton}>
                <Text style={styles.viewRouteText}>View Route Map</Text>
                <MaterialIcons name="arrow-forward" size={20} color="#1a73e8" />
              </TouchableOpacity>
            </View>
          ))
        )}

        {!selectedRoute && (
          <View style={styles.instructionContainer}>
            <MaterialIcons name="touch-app" size={36} color="#1a73e8" />
            <Text style={styles.instructionText}>
              {filteredRoutes.length > 0
                ? "Please select a bus route above to see details."
                : "Provide valid bus search data to see available routes."}
            </Text>
          </View>
        )}
      </ScrollView>

      {/* Modal for map */}
      <Modal visible={isModalVisible} animationType="slide" onRequestClose={() => setIsModalVisible(false)}>
        <SafeAreaView style={styles.modalContainer}>
          <TouchableOpacity style={styles.closeButton} onPress={() => setIsModalVisible(false)}>
            <MaterialIcons name="close" size={24} color="#fff" />
          </TouchableOpacity>
          {mapUrl && <WebView source={{ html: mapUrl }} style={styles.webviewFullScreen} onMessage={handleMessage} javaScriptEnabled domStorageEnabled />}
          {mapLoading && (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#1a73e8" />
              <Text style={styles.loadingText}>Loading map...</Text>
            </View>
          )}
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#121212', // Dark background
  },
  header: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#2a2a2a', borderBottomLeftRadius: 35, borderBottomRightRadius: 35
  },
  headerTitle: {
    fontSize: 25,
    fontWeight: '700',
    color: '#ffffff', // White text for dark theme
    textAlign: 'center',
  },
  headerSubtitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#e0e0e0', // Light gray for dark theme
    marginTop: 4,
    textAlign: 'center',
  },
  routeFilter: {
    fontSize: 14,
    color: '#7A5FFF', // Primary accent color
    marginTop: 8,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  routesContainer: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#2a2a2a', // Darker border
  },
  routesHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff', // White text
  },
  routeCount: {
    fontSize: 14,
    color: '#b0b0b0', // Light gray
  },
  routesList: {
    flexGrow: 0,
  },
  busRouteItem: {
    backgroundColor: '#2a2a2a', // Dark gray background
    padding: 10,
    marginRight: 10,
    borderRadius: 8,
  },
  selectedRouteItem: {
    backgroundColor: '#7A5FFF', // Primary accent color
  },
  partialMatchItem: {
    backgroundColor: '#332c4a', // Darker shade of purple
    borderWidth: 1,
    borderColor: '#5345D9', // Secondary accent color
  },
  busRouteText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff', // White text
  },
  partialMatchText: {
    fontSize: 10,
    fontWeight: '500',
    color: '#a195ff', // Lighter shade of primary color
    marginTop: 2,
  },
  matchLegend: {
    fontSize: 12,
    color: '#b0b0b0', // Light gray
    marginTop: 8,
    fontStyle: 'italic',
  },
  noRoutesText: {
    fontSize: 14,
    color: '#b0b0b0', // Light gray
    fontStyle: 'italic',
    marginTop: 10,
  },
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#121212', // Dark background
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#121212', // Dark background
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#b0b0b0', // Light gray
  },
  noDataContainer: {
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#1e1e1e', // Slightly lighter than background
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 3,
  },
  noDataText: {
    marginTop: 10,
    fontSize: 16,
    color: '#b0b0b0', // Light gray
    textAlign: 'center',
  },
  instructionContainer: {
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#1e1e1e', // Slightly lighter than background
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 3,
  },
  instructionText: {
    marginTop: 10,
    fontSize: 16,
    color: '#7A5FFF', // Primary accent color
    textAlign: 'center',
    fontWeight: '500',
  },
  busBox: {
    backgroundColor: '#1e1e1e', // Slightly lighter than background
    padding: 20,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 3,
  },
  busHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  busName: {
    fontSize: 20,
    fontWeight: '600',
    color: '#ffffff', // White text
  },
  routeNo: {
    fontSize: 14,
    fontWeight: '400',
    color: '#b0b0b0', // Light gray
    marginTop: 4,
  },
  partialMatchAlert: {
    fontSize: 12,
    fontWeight: '500',
    color: '#a195ff', // Lighter shade of primary color
    marginTop: 4,
  },
  routeContainer: {
    marginTop: 8,
  },
  routeEndpoint: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 8,
  },
  routeStop: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 2,
    marginVertical: 8,
  },
  stopLine: {
    position: 'absolute',
    left: 9,
    top: -16,
    bottom: -16,
    width: 2,
    backgroundColor: '#2a2a2a', // Darker border
  },
  routeTextContainer: {
    marginLeft: 12,
    flex: 1,
  },
  routeText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#ffffff', // White text
  },
  routeLabel: {
    fontSize: 13,
    fontWeight: '400',
    color: '#b0b0b0', // Light gray
    marginTop: 2,
  },
  stopText: {
    fontSize: 15,
    fontWeight: '400',
    color: '#ffffff', // White text
  },
  timingText: {
    fontSize: 13,
    fontWeight: '400',
    color: '#b0b0b0', // Light gray
    marginTop: 2,
  },
  viewRouteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#2a2a2a', // Darker border
  },
  viewRouteText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#7A5FFF', // Primary accent color
    marginRight: 8,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#000', // Black background for modal
  },
  webviewFullScreen: {
    flex: 1,
  },
  closeButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    zIndex: 1,
    backgroundColor: 'rgba(83, 69, 217, 0.8)', // Secondary accent color with transparency
    padding: 8,
    borderRadius: 20,
  },
});