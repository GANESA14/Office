import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React from 'react';
import DataScreen from './Bus';
import IndexScreen from './home';
import LiveScreen from './Live';
import AboutPage from './LoginPage/About';
import AddScreen from './LoginPage/Add';
import Addmore from './LoginPage/AddMore';
import Contributions from './LoginPage/contribute';
import ForgotPassword from './LoginPage/ForgotPassword';
import LoginScreens from './LoginPage/Login';
import Profile from './LoginPage/Profile';
const Stack = createNativeStackNavigator();

export default function App() {
    return (
        <NavigationContainer>
            <Stack.Navigator initialRouteName="Index">
                <Stack.Screen name="Index" component={IndexScreen} options={{ headerShown: false }} />
                <Stack.Screen name="Bus" component={DataScreen} options={{ headerShown: false }} />
                <Stack.Screen name="Add" component={AddScreen} options={{ title: "Add", headerStyle: { backgroundColor: 'black' }, headerTintColor: '#7A5FFF', }} />
                <Stack.Screen name="ForgotPassword" component={ForgotPassword} options={{ headerShown: false }} />
                <Stack.Screen name="LoginFlow" component={LoginScreens} options={{ headerShown: false, }} />
                <Stack.Screen name="Profile" component={Profile} options={{ headerShown: false }} />
                <Stack.Screen name="AddMore" component={Addmore} options={{ title: 'Payment', headerStyle: { backgroundColor: 'black' }, headerTintColor: '#7A5FFF' }} />
                <Stack.Screen name="AboutPage" component={AboutPage} options={{ headerShown: false }} />
                <Stack.Screen name="Contributions" component={Contributions} options={{ headerShown: false }} />
                <Stack.Screen name="Live" component={LiveScreen} options={{ headerShown: false }} />
            </Stack.Navigator>
        </NavigationContainer>
    );
}