import { getFirestore, doc, getDoc, setDoc, updateDoc } from "firebase/firestore";
import { initializeApp } from "firebase/app";
import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { useState, useRef, useEffect } from "react";
import {View,Text,TextInput,TouchableOpacity,StyleSheet,Alert,ScrollView,Animated,Dimensions,KeyboardAvoidingView,Platform,
} from "react-native";
import { Picker } from "@react-native-picker/picker";

const { width } = Dimensions.get("window");

const PaymentForm = () => {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const scaleAnim = useRef(new Animated.Value(0.9)).current;
  const spinValue = useRef(new Animated.Value(0)).current;
  const [selectedMethod, setSelectedMethod] = useState<"upi" | "bank" | null>(null);
  const [name, setName] = useState("");
  const [upi, setUpi] = useState("");
  const [upiName, setUpiName] = useState("");
  const [upiMobile, setUpiMobile] = useState("");
  const [upiProvider, setUpiProvider] = useState("Google Pay");
  const [bankName, setBankName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [ifsc, setIfsc] = useState("");
  const [accountType, setAccountType] = useState("Savings");
  const [branchName, setBranchName] = useState("");
  const [bankMobile, setBankMobile] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const firebaseConfig = {
      apiKey: "AIzaSyBjZwkq0JNo8q8JE8alMGzprDWKMx3-kis",
      authDomain: "bus-routes-b7f5b.firebaseapp.com",
      projectId: "bus-routes-b7f5b",
      storageBucket: "bus-routes-b7f5b.firebasestorage.app",
      messagingSenderId: "287910459440",
      appId: "1:287910459440:web:d0c58022cadc19e7e8d5f5",
      measurementId: "G-ESKM1H0QX1",
    };const app = initializeApp(firebaseConfig);
    const db = getFirestore(app);
    
  // Validation errors
  const [errors, setErrors] = useState<{[key: string]: string}>({});
  const [activeField, setActiveField] = useState<string | null>(null);

  // References
  const scrollViewRef = useRef<ScrollView | null>(null);

  // Spin animation for loading indicator
  const spin = spinValue.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg']
  });

// Function to save payment details
const savePaymentDetails = async () => {
  if (!validateForm()) {
    Alert.alert("Validation Error", "Please correct the errors in the form.");
    return;
  }

  setIsLoading(true);

  try {
    const paymentData = {
      name,
      selectedMethod,
      ...(selectedMethod === "upi"
        ? { upi, upiName, upiMobile, upiProvider }
        : { bankName, accountNumber, ifsc, accountType, branchName, bankMobile }),
    };

    await AsyncStorage.setItem("paymentDetails", JSON.stringify(paymentData));

    setShowSuccess(true);
    console.log("Saved Payment Details:", paymentData);

    setTimeout(() => {
      setShowSuccess(false);
    }, 3000);
  } catch (error) {
    console.error("Error saving payment details:", error);
    Alert.alert("Error", "Failed to save payment details.");
  } finally {
    setIsLoading(false);
  }
};

// Function to load saved details on component mount
const loadPaymentDetails = async () => {
  try {
    const storedData = await AsyncStorage.getItem("paymentDetails");
    if (storedData) {
      const parsedData = JSON.parse(storedData);
      console.log("Loaded Payment Details:", parsedData);

      // Set state with loaded data
      setName(parsedData.name || "");
      setSelectedMethod(parsedData.selectedMethod || null);
      
      if (parsedData.selectedMethod === "upi") {
        setUpi(parsedData.upi || "");
        setUpiName(parsedData.upiName || "");
        setUpiMobile(parsedData.upiMobile || "");
        setUpiProvider(parsedData.upiProvider || "Google Pay");
      } else if (parsedData.selectedMethod === "bank") {
        setBankName(parsedData.bankName || "");
        setAccountNumber(parsedData.accountNumber || "");
        setIfsc(parsedData.ifsc || "");
        setAccountType(parsedData.accountType || "Savings");
        setBranchName(parsedData.branchName || "");
        setBankMobile(parsedData.bankMobile || "");
      }
    }
  } catch (error) {
    console.error("Error loading payment details:", error);
  }
};
const writeData = async () => {
  if (!name || !selectedMethod) {
    Alert.alert("Error", "Please fill out all required fields");
    return;
  }

  const email = 'ganesa11421@gmail.com'; // User email (you can replace this dynamically)
  const timestamp = "Details"; // Unique key for each payment entry

  // Prepare Payment Data
  const paymentData = {
    name,
    selectedMethod,
    date: new Date(),
    ...(selectedMethod === "upi"
      ? { upi, upiName, upiMobile, upiProvider }
      : { bankName, accountNumber, ifsc, accountType, branchName, bankMobile }),
  };

  // Firestore reference
  const docRef = doc(db, "Write","User", email,"Account");

  try {
    const docSnap = await getDoc(docRef);

    if (!docSnap.exists()) {
      // Create a new document
      await setDoc(docRef, { [timestamp]: paymentData });
      Alert.alert("Success", "Payment details saved in Firestore!");
    } else {
      // Update existing document without overwriting old data
      await updateDoc(docRef, { [timestamp]: paymentData });
      Alert.alert("Success", "Payment details updated in Firestore!");
    }
  } catch (error) {
    console.error("Firestore Error:", error);
    Alert.alert("Error", "Failed to save payment details.");
  }
};
  
// Load details when component mounts
useEffect(() => {
  loadPaymentDetails();
}, []);
  // Run entrance animation on mount
  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  // Start spin animation when loading
  useEffect(() => {
    if (isLoading) {
      Animated.loop(
        Animated.timing(spinValue, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        })
      ).start();
    } else {
      spinValue.setValue(0);
    }
  }, [isLoading]);

  // Animation for payment method selection
  const methodAnimation = (method: "upi" | "bank") => {
    if (selectedMethod !== method) {
      // Animate form change
      Animated.sequence([
        Animated.timing(fadeAnim, {
          toValue: 0.7,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();
      
      selectMethod(method);
    }
  };

  const selectMethod = (method: "upi" | "bank") => {
    setSelectedMethod(method);
    setUpi("");
    setUpiName("");
    setUpiMobile("");
    setUpiProvider("Google Pay");
    setBankName("");
    setAccountNumber("");
    setIfsc("");
    setAccountType("Savings");
    setBranchName("");
    setBankMobile("");
    setErrors({});
  };

  // Validation functions
  const validateName = (value: string) => {
    if (!value.trim()) return "Name is required";
    if (value.trim().length < 3) return "Name must be at least 3 characters";
    if (!/^[a-zA-Z\s]+$/.test(value)) return "Name should contain only letters and spaces";
    return "";
  };

  const validateUpi = (value: string) => {
    if (!value.trim()) return "UPI ID is required";
    if (!/^[\w.-]+@[\w.-]+$/.test(value)) return "Invalid UPI ID format (example@provider)";
    return "";
  };

  const validateMobile = (value: string) => {
    if (!value.trim()) return "Mobile number is required";
    if (!/^\d{10}$/.test(value)) return "Mobile number must be 10 digits";
    return "";
  };

  const validateBankName = (value: string) => {
    if (!value.trim()) return "Bank name is required";
    if (value.trim().length < 3) return "Bank name must be at least 3 characters";
    return "";
  };

  const validateAccountNumber = (value: string) => {
    if (!value.trim()) return "Account number is required";
    if (!/^\d{9,18}$/.test(value)) return "Account number must be 9-18 digits";
    return "";
  };

  const validateIFSC = (value: string) => {
    if (!value.trim()) return "IFSC code is required";
    if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(value)) return "Invalid IFSC format (e.g., SBIN0123456)";
    return "";
  };

  const handleInput = (field: string, value: string, validator: (val: string) => string) => {
    const errorMessage = validator(value);
    setErrors(prev => ({
      ...prev,
      [field]: errorMessage
    }));
    
    // Update the state based on the field
    switch(field) {
      case 'name': setName(value); break;
      case 'upi': setUpi(value); break;
      case 'upiName': setUpiName(value); break;
      case 'upiMobile': setUpiMobile(value); break;
      case 'bankName': setBankName(value); break;
      case 'accountNumber': setAccountNumber(value); break;
      case 'ifsc': setIfsc(value.toUpperCase()); break;
      case 'branchName': setBranchName(value); break;
      case 'bankMobile': setBankMobile(value); break;
    }
  };

  const validateForm = () => {
    const newErrors: {[key: string]: string} = {};
    
    // Validate common fields
    newErrors.name = validateName(name);
    
    if (selectedMethod === "upi") {
      newErrors.upi = validateUpi(upi);
      newErrors.upiName = validateName(upiName);
      newErrors.upiMobile = validateMobile(upiMobile);
    } else if (selectedMethod === "bank") {
      newErrors.bankName = validateBankName(bankName);
      newErrors.accountNumber = validateAccountNumber(accountNumber);
      newErrors.ifsc = validateIFSC(ifsc);
      newErrors.branchName = validateName(branchName);
      newErrors.bankMobile = validateMobile(bankMobile);
    } else {
      newErrors.method = "Please select a payment method";
    }
    
    setErrors(newErrors);
    
    // Check if there are any errors
    return !Object.values(newErrors).some(error => error !== "");
  };

  const handleSave = async () => {
    savePaymentDetails();
    writeData();
    if (!validateForm()) {
      Alert.alert("Validation Error", "Please correct the errors in the form.");
      return;
    }

    // Show loading animation
    setIsLoading(true);

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      setShowSuccess(true);
      
      // Log data
      console.log({ 
        name, 
        selectedMethod,
        ...(selectedMethod === "upi" ? 
          { upi, upiName, upiMobile, upiProvider } : 
          { bankName, accountNumber, ifsc, accountType, branchName, bankMobile })
      });
      
      // Reset form after a delay
      setTimeout(() => {
        setShowSuccess(false);
      }, 3000);
    }, 1500);
  };

  const focusInput = (fieldName: string) => {
    setActiveField(fieldName);
    // Scroll to the input when focused
    setTimeout(() => {
      if (scrollViewRef.current) {
        scrollViewRef.current.scrollToEnd({ animated: true });
      }
    }, 100);
  };

  // Custom card rendering function
  const renderCard = (children: React.ReactNode) => (
    <Animated.View 
      style={[
        styles.card,
        {
          opacity: fadeAnim,
          transform: [
            { translateY: slideAnim },
            { scale: scaleAnim }
          ]
        }
      ]}
    >
      {children}
    </Animated.View>
  );

  // Custom input field rendering function
  const renderInputField = (
    label: string, 
    placeholder: string, 
    value: string, 
    field: string,
    validator: (val: string) => string,
    keyboardType: "default" | "email-address" | "numeric" | "phone-pad" = "default",
    secure: boolean = false,
    maxLength: number = 50,
    autoCapitalize: "none" | "sentences" | "words" | "characters" = "none"
  ) => (
    <>
      <Text style={styles.label}>
        {label}
        <Text style={styles.asterisk}>*</Text>
      </Text>
      <View style={styles.inputContainer}>
        <TextInput 
          style={[
            styles.input, 
            errors[field] ? styles.inputError : null,
            activeField === field ? styles.inputActive : null
          ]} 
          placeholder={placeholder} 
          placeholderTextColor="#6A6A8A" 
          value={value} 
          onChangeText={(value) => handleInput(field, value, validator)}
          keyboardType={keyboardType}
          maxLength={maxLength}
          secureTextEntry={secure}
          autoCapitalize={autoCapitalize}
          onFocus={() => focusInput(field)}
          onBlur={() => setActiveField(null)}
        />
        {!errors[field] && value ? (
          <View style={styles.checkMarkContainer}>
            <Text style={styles.checkMark}>✓</Text>
          </View>
        ) : null}
      </View>
      {errors[field] ? (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>⚠️ {errors[field]}</Text>
        </View>
      ) : null}
    </>
  );

  // Success screen
  if (showSuccess) {
    return (
      <View style={styles.successContainer}>
        <View style={styles.successCircle}>
          <Text style={styles.successIcon}>✓</Text>
        </View>
        <Text style={styles.successText}>Payment Details Saved!</Text>
        <Text style={styles.successSubtext}>Your payment method has been successfully saved.</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={{ flex: 1 }}
    >
      <View style={styles.background}>
        <ScrollView style={styles.container} ref={scrollViewRef} showsVerticalScrollIndicator={false}>
          <Animated.View
            style={{
              opacity: fadeAnim,
              transform: [
                { translateY: slideAnim },
                { scale: scaleAnim }
              ]
            }}
          >
            <View style={styles.headerContainer}>
              <Text style={styles.header}>Payment Details</Text>
              <View style={styles.headerLine} />
            </View>
          </Animated.View>

          {renderCard(
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>Personal Information</Text>
              {renderInputField(
                "Full Name", 
                "Enter your name", 
                name, 
                "name", 
                validateName
              )}
            </View>
          )}

          {renderCard(
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>Payment Method</Text>
              
              <View style={styles.methodContainer}>
                <TouchableOpacity 
                  style={[
                    styles.methodButton, 
                    selectedMethod === "upi" && styles.methodButtonSelected
                  ]} 
                  onPress={() => methodAnimation("upi")}
                >
                  <View style={styles.methodIcon}>
                    <Text style={styles.methodIconText}>📱</Text>
                  </View>
                  <Text style={[styles.methodText, selectedMethod === "upi" && styles.methodTextSelected]}>UPI</Text>
                </TouchableOpacity>
                
                <TouchableOpacity 
                  style={[
                    styles.methodButton, 
                    selectedMethod === "bank" && styles.methodButtonSelected
                  ]} 
                  onPress={() => methodAnimation("bank")}
                >
                  <View style={styles.methodIcon}>
                    <Text style={styles.methodIconText}>🏦</Text>
                  </View>
                  <Text style={[styles.methodText, selectedMethod === "bank" && styles.methodTextSelected]}>Bank</Text>
                </TouchableOpacity>
              </View>
              
              {errors.method ? (
                <View style={styles.errorContainer}>
                  <Text style={styles.errorText}>⚠️ {errors.method}</Text>
                </View>
              ) : null}
            </View>
          )}

          {selectedMethod === "upi" && (
            <Animated.View 
              style={[
                styles.card,
                {
                  opacity: fadeAnim,
                  transform: [{ translateY: slideAnim }]
                }
              ]}>
              <View style={styles.cardContent}>
                <Text style={styles.cardTitle}>UPI Details</Text>
                
                {renderInputField(
                  "UPI ID", 
                  "example@upi", 
                  upi, 
                  "upi", 
                  validateUpi, 
                  "email-address"
                )}
                
                {renderInputField(
                  "UPI Account Holder Name", 
                  "Enter account holder name", 
                  upiName, 
                  "upiName", 
                  validateName
                )}
                
                {renderInputField(
                  "UPI Linked Mobile Number", 
                  "Enter 10-digit mobile number", 
                  upiMobile, 
                  "upiMobile", 
                  validateMobile, 
                  "phone-pad", 
                  false, 
                  10
                )}
                
                <Text style={styles.label}>
                  UPI Provider<Text style={styles.asterisk}>*</Text>
                </Text>
                <View style={styles.pickerContainer}>
                  <Picker 
                    selectedValue={upiProvider} 
                    style={styles.picker} 
                    onValueChange={(itemValue) => setUpiProvider(itemValue)}
                  >
                    <Picker.Item label="Google Pay" value="Google Pay" />
                    <Picker.Item label="PhonePe" value="PhonePe" />
                    <Picker.Item label="Paytm" value="Paytm" />
                    <Picker.Item label="Amazon Pay" value="Amazon Pay" />
                    <Picker.Item label="BHIM" value="BHIM" />
                    <Picker.Item label="Other UPI App" value="Other" />
                  </Picker>
                </View>
              </View>
            </Animated.View>
          )}

          {selectedMethod === "bank" && (
            <Animated.View 
              style={[
                styles.card,
                {
                  opacity: fadeAnim,
                  transform: [{ translateY: slideAnim }]
                }
              ]}>
              <View style={styles.cardContent}>
                <Text style={styles.cardTitle}>Bank Account Details</Text>
                
                {renderInputField(
                  "Bank Name", 
                  "Enter bank name", 
                  bankName, 
                  "bankName", 
                  validateBankName
                )}
                
                <Text style={styles.label}>
                  Account Type<Text style={styles.asterisk}>*</Text>
                </Text>
                <View style={styles.pickerContainer}>
                  <Picker 
                    selectedValue={accountType} 
                    style={styles.picker} 
                    onValueChange={(itemValue) => setAccountType(itemValue)}
                  >
                    <Picker.Item label="Savings" value="Savings" />
                    <Picker.Item label="Current" value="Current" />
                    <Picker.Item label="Salary" value="Salary" />
                    <Picker.Item label="Fixed Deposit" value="Fixed Deposit" />
                  </Picker>
                </View>
                
                {renderInputField(
                  "Branch Name", 
                  "Enter branch name", 
                  branchName, 
                  "branchName", 
                  (val) => val.trim() ? "" : "Branch name is required"
                )}
                
                {renderInputField(
                  "Account Number", 
                  "Enter account number", 
                  accountNumber, 
                  "accountNumber", 
                  validateAccountNumber, 
                  "numeric", 
                  true, 
                  18
                )}
                
                {renderInputField(
                  "IFSC Code", 
                  "Enter IFSC code (e.g., SBIN0123456)", 
                  ifsc, 
                  "ifsc", 
                  validateIFSC, 
                  "default", 
                  false, 
                  11, 
                  "characters"
                )}
                
                {renderInputField(
                  "Account Holder's Mobile Number", 
                  "Enter 10-digit mobile number", 
                  bankMobile, 
                  "bankMobile", 
                  validateMobile, 
                  "phone-pad", 
                  false, 
                  10
                )}
              </View>
            </Animated.View>
          )}

          <TouchableOpacity 
            style={[
              styles.button, 
              (!name || !selectedMethod) ? styles.buttonDisabled : null,
              isLoading ? styles.buttonLoading : null
            ]} 
            onPress={handleSave}
            disabled={!name || !selectedMethod || isLoading}
          >
            {isLoading ? (
              <Animated.View style={{ transform: [{ rotate: spin }] }}>
                <Text style={styles.loadingText}>⟳</Text>
              </Animated.View>
            ) : (
              <Text style={styles.buttonText}>Save Payment Details</Text>
            )}
          </TouchableOpacity>
          <Text style={styles.mandatoryNote}>* Fields marked with an asterisk are mandatory</Text>
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  background: { 
    flex: 1, 
    backgroundColor: "#0C0C16"
  },
  container: { 
    flex: 1, 
    padding: 20,
  },
  headerContainer: {
    marginBottom: 24,
    alignItems: "center",
  },
  header: { 
    fontSize: 28, 
    fontWeight: "bold", 
    color: "#9D7FFF", 
    textAlign: "center"
  },
  headerLine: {
    width: 50,
    height: 4,
    backgroundColor: "#7A5FFF",
    borderRadius: 2,
    marginTop: 8,
  },
  card: {
    backgroundColor: "#1E1E2E", 
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 7,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "#2A2A40"
  },
  cardContent: {
    padding: 16
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: "#9D7FFF",
    marginBottom: 16,
    borderLeftWidth: 3,
    borderLeftColor: "#7A5FFF",
    paddingLeft: 10,
  },
  label: { 
    color: "#CDCDFF", 
    fontSize: 15, 
    marginTop: 12,
    marginBottom: 4,
    fontWeight: "500"
  },
  asterisk: {
    color: "#FF5252",
    marginLeft: 2,
    fontWeight: "bold"
  },
  inputContainer: {
    position: "relative",
    marginBottom: 4,
  },
  input: { 
    backgroundColor: "#2C2C44", 
    color: "#FFFFFF", 
    fontSize: 16, 
    padding: 14, 
    borderRadius: 8, 
    borderWidth: 1,
    borderColor: "#3C3C58",
    marginTop: 2
  },
  inputError: { 
    borderWidth: 1, 
    borderColor: "#FF5252" 
  },
  inputActive: {
    borderColor: "#7A5FFF",
    borderWidth: 2,
    backgroundColor: "#2C2C44",
  },
  checkMarkContainer: {
    position: "absolute",
    right: 12,
    top: "50%",
    marginTop: -8,
  },
  checkMark: {
    fontSize: 16,
    color: "#4ADE80",
    fontWeight: "bold"
  },
  errorContainer: {
    marginTop: 4,
    marginBottom: 8,
  },
  errorText: { 
    color: "#FF5252", 
    fontSize: 13,
  },
  pickerContainer: {
    backgroundColor: "#2C2C44",
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#3C3C58",
    marginTop: 2,
    marginBottom: 8,
    overflow: "hidden"
  },
  picker: { 
    color: "#FFFFFF", 
    height: 50,
  },
  methodContainer: { 
    flexDirection: "row", 
    justifyContent: "space-between",
    marginVertical: 8,
    marginBottom: 16
  },
  methodButton: { 
    flex: 1, 
    backgroundColor: "#25253E", 
    borderRadius: 10, 
    padding: 16, 
    marginHorizontal: 4,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "#2C2C44",
  },
  methodButtonSelected: { 
    borderColor: "#7A5FFF",
    backgroundColor: "#2C2C44"
  },
  methodIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: "#1A1A28",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8
  },
  methodIconText: {
    fontSize: 22
  },
  methodText: { 
    color: "#CDCDFF", 
    fontSize: 16,
    fontWeight: "600",
    marginTop: 4
  },
  methodTextSelected: { 
    color: "#9D7FFF", 
    fontWeight: "bold"
  },
  button: { 
    backgroundColor: "#7A5FFF", 
    marginTop: 8, 
    marginBottom: 8,
    borderRadius: 10, 
    padding: 16, 
    alignItems: "center",
    shadowColor: "#7A5FFF",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  buttonDisabled: { 
    backgroundColor: "#3C3C58", 
    opacity: 0.7,
    shadowOpacity: 0
  },
  buttonLoading: {
    backgroundColor: "#6A50E0"
  },
  buttonText: { 
    color: "#FFFFFF", 
    fontSize: 16, 
    fontWeight: "bold" 
  },
  loadingText: {
    fontSize: 24,
    color: "#FFFFFF",
    fontWeight: "bold"
  },
  mandatoryNote: { 
    color: "#8888AA", 
    fontSize: 13, 
    marginVertical: 15, 
    textAlign: "center" 
  },
  successContainer: {
    flex: 1,
    backgroundColor: "#0C0C16",
    alignItems: "center",
    justifyContent: "center",
    padding: 20
  },
  successCircle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: "#4ADE80",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 24
  },
  successIcon: {
    fontSize: 50,
    color: "white",
    fontWeight: "bold"
  },
  successText: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 12
  },
  successSubtext: {
    fontSize: 16,
    color: "#CDCDFF",
    textAlign: "center"
  }
});

export default PaymentForm;