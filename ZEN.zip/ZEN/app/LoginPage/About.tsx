import React from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { MaterialIcons, FontAwesome5, Ionicons } from "@expo/vector-icons";

const AboutScreen = () => {
  return (
    <View style={styles.container}>
      {/* Gradient Header */}
      <LinearGradient
        colors={["#7A5FFF", "#5345D9"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={styles.header}
      >
        <Text style={styles.headerText}>About the App</Text>
        <MaterialIcons name="directions-bus" size={28} color="#FFFFFF" />
      </LinearGradient>

      {/* Content */}
      <ScrollView 
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <MaterialIcons name="stars" size={24} color="#7A5FFF" />
            <Text style={styles.sectionTitle}>Features</Text>
          </View>
          
          <FeatureItem 
            icon={<MaterialIcons name="schedule" size={22} color="#7A5FFF" />}
            title="Accurate Bus Timings"
            description="Check schedules easily & reduce waiting time"
          />

          <FeatureItem 
            icon={<Ionicons name="location-outline" size={22} color="#7A5FFF" />}
            title="Real-Time Bus Tracking"
            description="See bus location on the map in real-time"
          />

          <FeatureItem 
            icon={<MaterialIcons name="notifications-active" size={22} color="#7A5FFF" />}
            title="Instant Travel Alerts"
            description="Get updates on delays & route changes"
          />

          <FeatureItem 
            icon={<FontAwesome5 name="search-location" size={20} color="#7A5FFF" />}
            title="Search & Filter"
            description="Find buses based on starting point & destination"
          />

          <FeatureItem 
            icon={<MaterialIcons name="language" size={22} color="#7A5FFF" />}
            title="Multi-Language Support"
            description="Available in Tamil & English"
            isLast={true}
          />
        </View>

        {/* Reward Policy Section */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <MaterialIcons name="card-giftcard" size={24} color="#7A5FFF" />
            <Text style={styles.sectionTitle}>Reward Policy</Text>
          </View>
          
          <FeatureItem 
            icon={<MaterialIcons name="payment" size={22} color="#7A5FFF" />}
            title="Payment Details Required"
            description="Add your UPI or Bank details to participate"
          />

          <FeatureItem 
            icon={<Ionicons name="lock-open-outline" size={22} color="#7A5FFF" />}
            title="Unlock Features"
            description="Access 'Add' & 'View Bus Stops' after adding payment details"
          />

          <FeatureItem 
            icon={<FontAwesome5 name="money-bill-wave" size={20} color="#7A5FFF" />}
            title="Cash Rewards"
            description="Earn ₹10 after adding 25 buses to our app"
          />

          <FeatureItem 
            icon={<MaterialIcons name="directions-bus" size={22} color="#7A5FFF" />}
            title="Daily Limit"
            description="Add 5-10 buses per day & track them in your dashboard"
            isLast={true}
          />
        </View>
      </ScrollView>
    </View>
  );
};
interface FeatureItemProps {
  icon: JSX.Element;
  title: string;
  description: string;
  isLast?: boolean;
}
// Feature Item Component for better organization
const FeatureItem: React.FC<FeatureItemProps> = ({ icon, title, description, isLast = false }) => {
  return (
    <View style={[styles.item, isLast ? null : styles.itemBorder]}>
      <View style={styles.iconContainer}>
        {icon}
      </View>
      <View style={styles.textContainer}>
        <Text style={styles.itemTitle}>{title}</Text>
        <Text style={styles.itemDescription}>{description}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#121212",
  },
  header: {
    padding: 25,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  headerText: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#FFF",
    marginRight: 10,
  },
  content: {
    flexGrow: 1,
    padding: 16,
  },
  card: {
    backgroundColor: "#1E1E1E",
    borderRadius: 16,
    shadowColor: "#7A5FFF",
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
    marginBottom: 20,
    overflow: "hidden",
  },
  cardHeader: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(122, 95, 255, 0.1)",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(122, 95, 255, 0.2)",
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFF",
    marginLeft: 8,
  },
  item: {
    flexDirection: "row",
    padding: 16,
  },
  itemBorder: {
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255, 255, 255, 0.1)",
  },
  iconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "rgba(122, 95, 255, 0.1)",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 12,
  },
  textContainer: {
    flex: 1,
  },
  itemTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#FFF",
    marginBottom: 4,
  },
  itemDescription: {
    fontSize: 14,
    color: "#BBBBBB",
  },
});

export default AboutScreen;