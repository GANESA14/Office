import React, { useState, useEffect } from "react";
import {View,Text,TextInput,TouchableOpacity,Animated,TouchableWithoutFeedback,Keyboard,Modal,ActivityIndicator,StyleSheet,Image,StatusBar,KeyboardAvoidingView,Platform,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { initializeApp, getApps, getApp } from "firebase/app";
import {getAuth,onAuthStateChanged,signInWithEmailAndPassword,createUserWithEmailAndPassword,sendEmailVerification,signOut,
} from "firebase/auth";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";

type NavigationProp = NativeStackNavigationProp<RootStackParamList, "Index">;
type RootStackParamList = {
  Index: undefined;
  hello: undefined;
  ForgotPassword: undefined;
  Profile: {MailtoPage:string};
};
const Toast = ({ visible, message, type = "success", onClose }) => {
  const [fadeAnim] = useState(new Animated.Value(0));
  useEffect(() => {
    if (visible) {
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start();
      const timer = setTimeout(() => {
        Animated.timing(fadeAnim, {
          toValue: 0,
          duration: 300,
          useNativeDriver: true,
        }).start(() => onClose());
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [visible]);
  if (!visible) return null;
  return (
    <Animated.View
      style={[
        styles.toast,
        {
          backgroundColor: type === "success" ? "#10B981" : "#EF4444",
          opacity: fadeAnim,
          transform: [
            {
              translateY: fadeAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [20, 0],
              }),
            },
          ],
        },
      ]}
    >
      <Ionicons 
        name={type === "success" ? "checkmark-circle" : "alert-circle"} 
        size={20} 
        color="#FFFFFF" 
      />
      <Text style={styles.toastText}>{message}</Text>
    </Animated.View>
  );
};
const CustomModal = ({ visible, title, message, onClose }) => {
  return (
    <Modal transparent visible={visible} animationType="fade">
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>{title}</Text>
          </View>
          <Text style={styles.modalMessage}>{message}</Text>
          <TouchableOpacity 
            style={styles.modalButton} 
            onPress={onClose}
            activeOpacity={0.8}
          >
            <Text style={styles.modalButtonText}>OK</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};
const LoadingSpinner = ({ visible }) => {
  if (!visible) return null;

  return (
    <View style={styles.spinnerOverlay}>
      <View style={styles.spinnerContainer}>
        <ActivityIndicator size="large" color="#5345D9" />
        <Text style={styles.spinnerText}>Please wait...</Text>
      </View>
    </View>
  );
};
const firebaseConfig = {
  apiKey: "AIzaSyBjZwkq0JNo8q8JE8alMGzprDWKMx3-kis",
  authDomain: "bus-routes-b7f5b.firebaseapp.com",
  projectId: "bus-routes-b7f5b",
  storageBucket: "bus-routes-b7f5b.firebasestorage.app",
  messagingSenderId: "287910459440",
  appId: "1:287910459440:web:d0c58022cadc19e7e8d5f5",
  measurementId: "G-ESKM1H0QX1",
};
let app;
if (getApps().length === 0) {
  app = initializeApp(firebaseConfig);
} else {
  app = getApp();
}
const auth = getAuth(app);
export default function App() {
  const navigation = useNavigation<NavigationProp>();
  const [user, setUser] = useState<any>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isSignup, setIsSignup] = useState(false);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState({ visible: false, message: "", type: "success" });
  const [modal, setModal] = useState({ visible: false, title: "", message: "" });
  const [emailFocused, setEmailFocused] = useState(false);
  const [passwordFocused, setPasswordFocused] = useState(false);
  const [confirmPasswordFocused, setConfirmPasswordFocused] = useState(false);
  
  useEffect(() => {
    const loadUser = async () => {
      const storedUser = await AsyncStorage.getItem("user");
      if (storedUser) {
        const parsedUser = JSON.parse(storedUser);
        setUser(parsedUser);
        navigation.replace("Profile", { userEmail: parsedUser.email });
      }
    };
    loadUser();
    
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setUser(user);
        await AsyncStorage.setItem("user", JSON.stringify(user));

        if (user.emailVerified) {
          navigation.navigate("Profile", { userEmail: user.email });

        } else {
          setModal({
            visible: true,
            title: "Verification Required",
            message: "Please verify your email before logging in.",
          });
          signOut(auth);
        }
      } else {
        setUser(null);
        await AsyncStorage.removeItem("user");
      }
    });
    return () => unsubscribe();
  }, []);
  
  const handleLogin = async () => {
    if (!email || !password) {
      setModal({
        visible: true,
        title: "Missing Fields",
        message: "Please fill in all fields.",
      });
      return;
    }
    setLoading(true);
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      
      if (!user.emailVerified) {
        setModal({
          visible: true,
          title: "Verification Required",
          message: "Please verify your email before logging in.",
        });
        setLoading(false);
        return;
      }
      
      await AsyncStorage.setItem("user", JSON.stringify(user));
      setToast({
        visible: true,
        message: "Logged in successfully!",
        type: "success",
      });
      
      navigation.navigate("Profile", { userEmail: user.email });

    } catch (error) {
      setModal({
        visible: true,
        title: "Login Failed",
        message: "Invalid email or password. Please try again.",
      });
    } finally {
      setLoading(false);
    }
  };
  
  const handleSignup = async () => {
    if (!email || !password || !confirmPassword) {
      setModal({
        visible: true,
        title: "Missing Fields",
        message: "Please fill in all fields.",
      });
      return;
    }
    if (password !== confirmPassword) {
      setModal({
        visible: true,
        title: "Password Mismatch",
        message: "Passwords do not match. Please try again.",
      });
      return;
    }
    setLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      
      await sendEmailVerification(user);
      setModal({
        visible: true,
        title: "Verification Email Sent",
        message: "Please check your email to verify your account.",
      });
      await AsyncStorage.setItem("user", JSON.stringify(user));
    } catch (error) {
      setModal({
        visible: true,
        title: "Sign Up Failed",
        message: error.message,
      });
    } finally {
      setLoading(false);
    }
  };
  

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor="#121212" />
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"}style={styles.container}>
          {user ? (
            <View style={styles.welcomeContainer}>
              <Text style={styles.welcomeText}>Welcome, {user.email}!</Text>
            </View>
          ) : (
            <View style={styles.authContainer}>
              <View style={styles.logoContainer}>
                <View style={styles.logoCircle}>
                  <Ionicons name="bus-outline" size={36} color="#7A5FFF" />
                </View>
              </View>
              
              <Text style={styles.headerText}>
                {isSignup ? "Create Account" : "Welcome"}
              </Text>
              <Text style={styles.subHeaderText}>
                {isSignup 
                  ? "Sign up to get started with BusRoute" 
                  : "Login to continue to with your account"}
              </Text>

              <View style={styles.inputContainer}>
                <View style={[
                  styles.inputWrapper,
                  emailFocused && styles.inputWrapperFocused
                ]}>
                  <Ionicons name="mail-outline" size={22} color={emailFocused ? "#7A5FFF" : "#6D7A8C"} />
                  <TextInput
                    placeholder="Email"
                    value={email}
                    onChangeText={setEmail}
                    style={styles.input}
                    autoCapitalize="none"
                    keyboardType="email-address"
                    placeholderTextColor="#6D7A8C"
                    onFocus={() => setEmailFocused(true)}
                    onBlur={() => setEmailFocused(false)}
                  />
                </View>

                <View style={[
                  styles.inputWrapper,
                  passwordFocused && styles.inputWrapperFocused
                ]}>
                  <Ionicons 
                    name="lock-closed-outline" 
                    size={22} 
                    color={passwordFocused ? "#7A5FFF" : "#6D7A8C"} 
                  />
                  <TextInput
                    placeholder="Password"
                    secureTextEntry={!showPassword}
                    value={password}
                    onChangeText={setPassword}
                    style={styles.input}
                    placeholderTextColor="#6D7A8C"
                    onFocus={() => setPasswordFocused(true)}
                    onBlur={() => setPasswordFocused(false)}
                  />
                  <TouchableOpacity
                    onPress={() => setShowPassword(!showPassword)}
                    style={styles.eyeIcon}
                  >
                    <Ionicons
                      name={showPassword ? "eye-off-outline" : "eye-outline"}
                      size={22}
                      color="#6D7A8C"
                    />
                  </TouchableOpacity>
                </View>

                {!isSignup && (
                  <TouchableOpacity 
                    onPress={() => navigation.navigate("ForgotPassword")}
                    style={styles.forgotPasswordContainer}
                  >
                    <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
                  </TouchableOpacity>
                )}

                {isSignup && (
                  <View style={[
                    styles.inputWrapper,
                    confirmPasswordFocused && styles.inputWrapperFocused
                  ]}>
                    <Ionicons 
                      name="lock-closed-outline" 
                      size={22} 
                      color={confirmPasswordFocused ? "#7A5FFF" : "#6D7A8C"} 
                    />
                    <TextInput
                      placeholder="Confirm Password"
                      secureTextEntry={!showConfirmPassword}
                      value={confirmPassword}
                      onChangeText={setConfirmPassword}
                      style={styles.input}
                      placeholderTextColor="#6D7A8C"
                      onFocus={() => setConfirmPasswordFocused(true)}
                      onBlur={() => setConfirmPasswordFocused(false)}
                    />
                    <TouchableOpacity
                      onPress={() => setShowConfirmPassword(!showConfirmPassword)}
                      style={styles.eyeIcon}
                    >
                      <Ionicons
                        name={showConfirmPassword ? "eye-off-outline" : "eye-outline"}
                        size={22}
                        color="#6D7A8C"
                      />
                    </TouchableOpacity>
                  </View>
                )}
              </View>

              <TouchableOpacity
                style={styles.button}
                onPress={isSignup ? handleSignup : handleLogin}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={['#5345D9', '#7A5FFF']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.buttonGradient}
                >
                  <Text style={styles.buttonText}>
                    {isSignup ? "Create Account" : "Login"}
                  </Text>
                </LinearGradient>
              </TouchableOpacity>

              <View style={styles.footerContainer}>
                <Text style={styles.footerText}>
                  {isSignup ? "Already have an account? " : "Don't have an account? "}
                </Text>
                <TouchableOpacity onPress={() => {
                  setIsSignup(!isSignup);
                  setEmail("");
                  setPassword("");
                  setConfirmPassword("");
                }}>
                  <Text style={styles.footerLink}>
                    {isSignup ? "Login In" : "Sign Up"}
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          <LoadingSpinner visible={loading} />
          <Toast
            visible={toast.visible}
            message={toast.message}
            type={toast.type}
            onClose={() => setToast({ ...toast, visible: false })}
          />
          <CustomModal
            visible={modal.visible}
            title={modal.title}
            message={modal.message}
            onClose={() => setModal({ ...modal, visible: false })}
          />
        </KeyboardAvoidingView>
      </TouchableWithoutFeedback>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#121212",
  },
  container: {
    flex: 1,
    backgroundColor: "#121212",
  },
  welcomeContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  welcomeText: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#FFFFFF",
    textAlign: "center",
  },
  authContainer: {
    flex: 1,
    justifyContent: "center",
    padding: 24,
  },
  logoContainer: {
    alignItems: "center",
    marginBottom: 32,
  },
  logoCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: "#1E1E1E",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 16,
  },
  logoText: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#FFFFFF",
  },
  headerText: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#FFFFFF",
    textAlign: "center",
    marginBottom: 8,
  },
  subHeaderText: {
    fontSize: 16,
    color: "#9E9E9E",
    textAlign: "center",
    marginBottom: 32,
  },
  inputContainer: {
    marginBottom: 24,
  },
  inputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#1E1E1E",
    borderWidth: 1,
    borderColor: "#333333",
    borderRadius: 12,
    marginBottom: 16,
    paddingHorizontal: 16,
    height: 56,
  },
  inputWrapperFocused: {
    borderColor: "#5345D9",
    borderWidth: 1.5,
    backgroundColor: "#1E1E1E",
  },
  input: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 10,
    color: "#FFFFFF",
    fontSize: 16,
  },
  eyeIcon: {
    padding: 8,
  },
  forgotPasswordContainer: {
    alignItems: "flex-end",
    marginBottom: 16,
  },
  forgotPasswordText: {
    color: "#7A5FFF",
    fontSize: 14,
    fontWeight: "500",
  },
  button: {
    borderRadius: 12,
    overflow: "hidden", 
    shadowColor: "#5345D9",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
    marginBottom: 24,
  },
  buttonGradient: {
    paddingVertical: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  buttonText: {
    color: "#FFFFFF",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "600",
  },
  footerContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  footerText: {
    fontSize: 14,
    color: "#9E9E9E",
  },
  footerLink: {
    fontSize: 14,
    fontWeight: "600",
    color: "#7A5FFF",
  },
  spinnerOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0, 0, 0, 0.7)",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 1000,
  },
  spinnerContainer: {
    backgroundColor: "#1E1E1E",
    padding: 24,
    borderRadius: 16,
    alignItems: "center",
    shadowColor: "#000000",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  spinnerText: {
    marginTop: 12,
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: "500",
  },
  toast: {
    position: "absolute",
    bottom: 32,
    left: 20,
    right: 20,
    padding: 16,
    borderRadius: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 5,
    zIndex: 1000,
  },
  toastText: {
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: "500",
    marginLeft: 8,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.7)",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 1000,
  },
  modalContent: {
    backgroundColor: "#1E1E1E",
    borderRadius: 16,
    width: "85%",
    maxWidth: 400,
    shadowColor: "#000000",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    elevation: 8,
    overflow: "hidden",
  },
  modalHeader: {
    borderBottomWidth: 1,
    borderBottomColor: "#333333",
    paddingVertical: 16,
    paddingHorizontal: 20,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: "#FFFFFF",
    textAlign: "center",
  },
  modalMessage: {
    fontSize: 16,
    color: "#CCCCCC",
    marginVertical: 24,
    paddingHorizontal: 20,
    textAlign: "center",
    lineHeight: 24,
  },
  modalButton: {
    backgroundColor: "#5345D9",
    marginHorizontal: 20,
    marginBottom: 20,
    paddingVertical: 12,
    borderRadius: 10,
  },
  modalButtonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "600",
    textAlign: "center",
  },
});