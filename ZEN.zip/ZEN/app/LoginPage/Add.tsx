import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, ScrollView, TouchableOpacity, StatusBar,Alert } from 'react-native';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useRoute } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import {  MaterialIcons,  Ionicons,  FontAwesome5,  Feather,  MaterialCommunityIcons,  AntDesign, Entypo,Octicons} from '@expo/vector-icons';
import { getFirestore, doc, getDoc, setDoc, updateDoc } from "firebase/firestore";
import { initializeApp } from "firebase/app";
import {Picker} from '@react-native-picker/picker';
interface BusInfo {
  busName: string;
  busNumber: string;
  route: { stop: string; time: string }[]; 
}

const BusInfoPage: React.FC = () => {
  const [busName, setBusName] = useState<string>('');
  const [busNumber, setBusNumber] = useState<string>('');
  const [stops, setStops] = useState<{ stop: string; time: string }[]>([{ stop: '', time: '' }]);
  const [source, setSource] = useState<string>('');
  const [destination, setDestination] = useState<string>('');
  const [busList, setBusList] = useState<BusInfo[]>([]);
  const route = useRoute<any>(); 
  const { PassingMail } = route.params || { PassingMail: [] };

  const [isSourceTimePickerVisible, setSourceTimePickerVisible] = useState<boolean>(false);
  const [isDestinationTimePickerVisible, setDestinationTimePickerVisible] = useState<boolean>(false);
  const [isStopTimePickerVisible, setStopTimePickerVisible] = useState<number | null>(null);
  const firebaseConfig = {
    apiKey: "AIzaSyBjZwkq0JNo8q8JE8alMGzprDWKMx3-kis",
    authDomain: "bus-routes-b7f5b.firebaseapp.com",
    projectId: "bus-routes-b7f5b",
    storageBucket: "bus-routes-b7f5b.firebasestorage.app",
    messagingSenderId: "287910459440",
    appId: "1:287910459440:web:d0c58022cadc19e7e8d5f5",
    measurementId: "G-ESKM1H0QX1",
  };const app = initializeApp(firebaseConfig);
  const db = getFirestore(app);
  
  const handleAddStop = () => {
    setStops([...stops, { stop: '', time: '' }]);
  };

  const handleStopChange = (text: string, index: number, field: 'stop' | 'time') => {
    const newStops = stops.map((stop, i) =>
      i === index ? { ...stop, [field]: text } : stop
    );
    setStops(newStops);
  };

  const handleDeleteStop = (index: number) => {
    const updatedStops = stops.filter((_, i) => i !== index);
    setStops(updatedStops);
  };

  const handleTimeConfirm = (time: Date, type: 'source' | 'destination' | 'stop' | null, stopIndex: number | null) => {
    const hours = time.getHours();
    const minutes = time.getMinutes();
    const formattedTime = `${hours < 10 ? '0' + hours : hours}:${minutes < 10 ? '0' + minutes : minutes}`;
    
    if (type === 'source') {
      setSource(formattedTime);
      setSourceTimePickerVisible(false);
    } else if (type === 'destination') {
      setDestination(formattedTime);
      setDestinationTimePickerVisible(false);
    } else if (type === 'stop' && stopIndex !== null) {
      const updatedStops = [...stops];
      updatedStops[stopIndex].time = formattedTime;
      setStops(updatedStops);
      setStopTimePickerVisible(null);
    }
  };
const [SourceName, SetSourceName] = useState("");
  const [DestName, SetDestName] = useState("");

  const writeData = async () => {
    if (!source || !destination || !busName || !busNumber) {
      Alert.alert("Error", "Please fill out all required fields");
      return;
    }
  
    const email = PassingMail;
  
    const mapName = `Route_${new Date().getTime()}`;
  
    // Auto-generate a contribution message
    const contribution = `Added new route: ${busName} (${busNumber})`;
  
    const docRef = doc(db, "Write", "User", email, "Contributes");
  
    // Create a structured route array
    const route = [
      { stop: SourceName, time: source },
      ...stops.filter((stop) => stop.stop.trim() !== ""),
      { stop: DestName, time: destination },
    ];
  
    // Bus information object
    const busInfo = {
      busName,
      busNumber,
      route,
      timestamp: new Date(),
    };
  
    // Firestore data structure
    const updateData = {
      [mapName]: {
        contribution,
        date: new Date(),
        busInfo,
      },
    };
  
    try {
      const docSnap = await getDoc(docRef);
  
      if (!docSnap.exists()) {
        await setDoc(docRef, updateData);
        Alert.alert("Success", "New document created in Firestore!");
      } else {
        await updateDoc(docRef, updateData);
        Alert.alert("Success", "Data updated in Firestore!");
      }
  
      // Reset form fields after successful write
      setBusList([...busList, busInfo]);
      setBusName("");
      setBusNumber("");
      setStops([{ stop: "", time: "" }]);
      setSource("");
      setDestination("");
    } catch (error) {
      console.error("Firestore Error:", error);
      Alert.alert("Error", "Failed to write data to Firestore.");
    }
  };
  
  return (
    <>
      <StatusBar barStyle="light-content" />
      <LinearGradient
        colors={['#121212', '#1E1E1E']}
        style={styles.container}
      >
        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <View style={styles.headerContainer}>
            <FontAwesome5 name="route" size={30} color="#7A5FFF" />
            <Text style={styles.title}>Add Bus</Text>
          </View>
          
          <View style={styles.sectionHeader}>
            <MaterialCommunityIcons name="bus-articulated-front" size={24} color="#7A5FFF" />
            <Text style={styles.subtitle}>Bus Details</Text>
          </View>
          
          <View style={styles.inputContainer}>
            <MaterialCommunityIcons name="bus-side" size={20} color="#7A5FFF" style={styles.inputIcon} />
            <TextInput style={styles.input} placeholder="Bus Name" placeholderTextColor="#6C6C6C"value={busName} onChangeText={setBusName}
            />
          </View>
          <Picker
    onValueChange={setBusName}
    style={styles.input}
    dropdownIconColor="#A9A6FF"
  >
    <Picker.Item label="Bus Type" value="" />
    <Picker.Item label="Govt Bus" value="Govt Bus" />
    <Picker.Item label="Private Bus" value="Private Bus" />

  </Picker>
          <View style={styles.inputContainer}>
            <Octicons name="number" size={20} color="#7A5FFF"style={styles.inputIcon} />
            <TextInput 
              style={styles.input} 
              placeholder="TN72AD1234" 
              placeholderTextColor="#6C6C6C"
              value={busNumber} autoCapitalize='characters'
              onChangeText={setBusNumber} 
              keyboardType='default'maxLength={11}
            />
          </View>

          <View style={styles.sectionHeader}>
            <Feather name="map" size={22} color="#7A5FFF" />
            <Text style={styles.subtitle}>Route Information</Text>
          </View>
          
          <View style={styles.cardContainer}>
            <LinearGradient 
              colors={['#1A1A1A', '#232323']} 
              style={styles.card}
            >
              <View style={styles.cardHeader}>
                <MaterialCommunityIcons name="ray-start" size={22} color="#7A5FFF" />
                <TextInput placeholder='Enter Source' style={styles.input}
                onChangeText={SetSourceName} placeholderTextColor={'#6C6C6C'}/>
              </View>
              <View style={styles.timeContainer}>
                {/* <TextInput 
                  style={styles.timeDisplay} 
                  placeholder="00:00" 
                  placeholderTextColor="#6C6C6C"
                  value={source} 
                  editable={false} 
                /> */}
                <TouchableOpacity 
                  onPress={() => setSourceTimePickerVisible(true)} 
                  style={styles.timeButton}
                >
                  <AntDesign name="clockcircleo" size={18} color="#FFFFFF" />
                  <Text style={styles.timeButtonText}>{source ? source: "Set"}</Text>
                </TouchableOpacity>
              </View>
            </LinearGradient>

            <LinearGradient 
              colors={['#1A1A1A', '#232323']} 
              style={styles.card}
            >
              <View style={styles.cardHeader}>
                <MaterialCommunityIcons name="ray-end" size={22} color="#5345D9" />
                <TextInput placeholder='Enter Destination' style={styles.input}
                onChangeText={SetDestName} placeholderTextColor={'#6C6C6C'}/>
              </View>
              <View style={styles.timeContainer}>
                {/* <TextInput 
                  style={styles.timeDisplay} 
                  placeholder="00:00" 
                  placeholderTextColor="#6C6C6C"
                  value={destination} 
                  editable={false}
                /> */}
                <TouchableOpacity 
                  onPress={() => setDestinationTimePickerVisible(true)} 
                  style={styles.timeButton}
                >
                  <AntDesign name="clockcircleo" size={18} color="#FFFFFF" />
                  <Text style={styles.timeButtonText}>{destination ? destination : "Set"}</Text>
                </TouchableOpacity>
              </View>
            </LinearGradient>
          </View>

          <View style={styles.sectionHeader}>
            <Entypo name="dots-three-vertical" size={22} color="#7A5FFF" />
            <Text style={styles.subtitle}>Intermediate Stops</Text>
          </View>
          
          {stops.map((stop, index) => (
            <LinearGradient 
              key={index}
              colors={['#1A1A1A', '#232323']} 
              style={styles.stopCard}
            >
              <View style={styles.stopHeader}>
                <FontAwesome5 name="map-pin" size={18} color="#7A5FFF" />
                <Text style={styles.stopHeaderText}>Stop {index + 1}</Text>
                <View style={styles.stopBadge}>
                  <Text style={styles.stopBadgeText}>{index + 1}</Text>
                </View>
              </View>
              
              <View style={styles.inputContainer}>
                <Entypo name="location" size={20} color="#7A5FFF" style={styles.inputIcon} />
                <TextInput 
                  style={styles.input} 
                  placeholder="Stop Name" 
                  placeholderTextColor="#6C6C6C"
                  value={stop.stop} 
                  onChangeText={(text) => handleStopChange(text, index, 'stop')}
                />
              </View>
              
              <View style={styles.timeContainer}>
                {/* <TextInput 
                  style={styles.timeDisplay} 
                  placeholder="00:00" 
                  placeholderTextColor="#6C6C6C"
                  value={stop.time} 
                  editable={false}
                /> */}
                <TouchableOpacity 
                  onPress={() => setStopTimePickerVisible(index)} 
                  style={styles.timeButton}
                >
                  <AntDesign name="clockcircleo" size={18} color="#FFFFFF" />
                  <Text style={styles.timeButtonText}>{stop.time ? stop.time : "Set"}</Text>
                </TouchableOpacity>
              </View>
              
              <TouchableOpacity
                onPress={() => handleDeleteStop(index)}
                style={styles.deleteButton}
              >
                <Feather name="trash-2" size={18} color="#FFFFFF" />
                <Text style={styles.deleteButtonText}>Remove</Text>
              </TouchableOpacity>
            </LinearGradient>
          ))}
          
          <TouchableOpacity onPress={handleAddStop} style={styles.addButton}>
            <LinearGradient
              colors={['#7A5FFF', '#5345D9']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.gradientButton}
            >
              <AntDesign name="pluscircleo" size={18} color="#FFFFFF" />
              <Text style={styles.buttonText}>Add Stop</Text>
            </LinearGradient>
          </TouchableOpacity>
          
          <TouchableOpacity onPress={writeData} style={styles.submitButton}>
            <LinearGradient
              colors={['#5345D9', '#7A5FFF']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.gradientButton}
            >
              <Feather name="save" size={18} color="#FFFFFF" />
              <Text style={styles.buttonText}>Save </Text>
            </LinearGradient>
          </TouchableOpacity>

          {busList.length > 0 && (
            <>
              <View style={styles.sectionHeader}>
                <MaterialCommunityIcons name="playlist-check" size={24} color="#7A5FFF" />
                <Text style={styles.subtitle}>Saved Routes</Text>
                <View style={styles.countBadge}>
                  <Text style={styles.countBadgeText}>{busList.length}</Text>
                </View>
              </View>

              {busList.map((bus, index) => (
                <LinearGradient 
                  key={index}
                  colors={['#1E1E1E', '#252525']} 
                  style={styles.busInfoCard}
                >
                  <View style={styles.busInfoHeader}>
                    <MaterialCommunityIcons name="bus-clock" size={24} color="#7A5FFF" />
                    <Text style={styles.busInfoTitle}>{bus.busName} - {bus.busNumber}</Text>
                  </View>
                  
                  <View style={styles.routeContainer}>
                    {bus.route.map((routeStop, stopIdx) => (
                      <View key={stopIdx} style={styles.routeItem}>
                        <View style={styles.routeLine}>
                          {stopIdx === 0 ? (
                            <MaterialCommunityIcons name="ray-start-arrow" size={24} color="#7A5FFF" />
                          ) : stopIdx === bus.route.length - 1 ? (
                            <MaterialCommunityIcons name="ray-end-arrow" size={24} color="#5345D9" />
                          ) : (
                            <Entypo name="dot-single" size={24} color="#7A5FFF" />
                          )}
                          {stopIdx !== bus.route.length - 1 && (
                            <View style={styles.verticalLine} />
                          )}
                        </View>
                        <View style={styles.routeDetails}>
                          <Text style={styles.routeStopName}>{routeStop.stop}</Text>
                          <View style={styles.timeRow}>
                            <AntDesign name="clockcircleo" size={14} color="#AAAAAA" />
                            <Text style={styles.routeStopTime}>{routeStop.time}</Text>
                          </View>
                        </View>
                      </View>
                    ))}
                  </View>

                  <View style={styles.busInfoFooter}>
                    <View style={styles.busInfoStat}>
                      <FontAwesome5 name="map-signs" size={14} color="#7A5FFF" />
                      <Text style={styles.busInfoStatText}>{bus.route.length} stops</Text>
                    </View>
                    <View style={styles.busInfoStat}>
                      <MaterialCommunityIcons name="map-marker-distance" size={14} color="#7A5FFF" />
                      <Text style={styles.busInfoStatText}>Full Route</Text>
                    </View>
                    <TouchableOpacity style={styles.viewRouteButton}>
                      <Text style={styles.viewRouteText}>Details</Text>
                      <AntDesign name="right" size={12} color="#7A5FFF" />
                    </TouchableOpacity>
                  </View>
                </LinearGradient>
              ))}
            </>
          )}
        </ScrollView>
      </LinearGradient>

      <DateTimePickerModal
        isVisible={isSourceTimePickerVisible}
        mode="time"
        onConfirm={(time) => handleTimeConfirm(time, 'source', null)}
        onCancel={() => setSourceTimePickerVisible(false)}
        themeVariant="dark"
      />
      
      <DateTimePickerModal
        isVisible={isDestinationTimePickerVisible}
        mode="time"
        onConfirm={(time) => handleTimeConfirm(time, 'destination', null)}
        onCancel={() => setDestinationTimePickerVisible(false)}
        themeVariant="dark"
      />
      
      {isStopTimePickerVisible !== null && (
        <DateTimePickerModal
          isVisible={true}
          mode="time"
          onConfirm={(time) => handleTimeConfirm(time, 'stop', isStopTimePickerVisible)}
          onCancel={() => setStopTimePickerVisible(null)}
          themeVariant="dark"
        />
      )}
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  scrollContainer: {
    flexGrow: 1,
    padding: 20,
  },
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 32,
    fontWeight: '800',
    textAlign: 'center',
    color: '#FFFFFF',
    letterSpacing: 0.8,
    marginLeft: 12,
    textShadowColor: '#7A5FFF',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 8,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 16,
    marginBottom: 12,
  },
  subtitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#7A5FFF',
    letterSpacing: 0.5,
    marginLeft: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1A1A1A',
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#333333',
    overflow: 'hidden',
  },
  inputIcon: {
    padding: 12,
  },
  input: {
    flex: 1,
    height: 50,
    color: '#FFFFFF',
    fontSize: 16,
    paddingHorizontal: 8,
  },
  cardContainer: {
    marginVertical: 8,
  },
  card: {
    borderRadius: 12,
    marginBottom: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: '#333333',
    shadowColor: '#7A5FFF',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  timeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  timeDisplay: {
    backgroundColor: '#242424',
    color: '#FFFFFF',
    fontSize: 16,
    padding: 10,
    borderRadius: 8,
    width: '40%',
    textAlign: 'center',
    borderWidth: 1,
    borderColor: '#333333',
  },
  timeButton: {
    flexDirection: 'row',
    backgroundColor: '#5345D9',
    borderRadius: 8,
    padding: 10,
    alignItems: 'center',
    justifyContent: 'center',
    width: '55%',
  },
  timeButtonText: {
    color: '#FFFFFF',
    marginLeft: 8,
    fontWeight: '500',
  },
  stopCard: {
    borderRadius: 12,
    marginBottom: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: '#333333',
    shadowColor: '#7A5FFF',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
  },
  stopHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  stopHeaderText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '600',
    marginLeft: 8,
    flex: 1,
  },
  stopBadge: {
    backgroundColor: '#7A5FFF',
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stopBadgeText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 12,
  },
  deleteButton: {
    backgroundColor: '#FF3B30',
    flexDirection: 'row',
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 12,
  },
  deleteButtonText: {
    color: '#FFFFFF',
    fontWeight: '500',
    marginLeft: 6,
  },
  addButton: {
    marginBottom: 16,
  },
  submitButton: {
    marginBottom: 32,
  },
  gradientButton: {
    flexDirection: 'row',
    borderRadius: 12,
    padding: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: '600',
    fontSize: 16,
    marginLeft: 8,
  },
  busInfoCard: {
    borderRadius: 16,
    marginBottom: 20,
    padding: 16,
    borderWidth: 1,
    borderColor: '#333333',
    shadowColor: '#7A5FFF',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  busInfoHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#333333',
  },
  busInfoTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '700',
    marginLeft: 10,
  },
  routeContainer: {
    marginTop: 8,
  },
  routeItem: {
    flexDirection: 'row',
    marginBottom: 4,
  },
  routeLine: {
    alignItems: 'center',
    width: 30,
  },
  verticalLine: {
    width: 2,
    height: 30,
    backgroundColor: '#5345D9',
    marginTop: 2,
  },
  routeDetails: {
    flex: 1,
    marginLeft: 12,
    marginBottom: 8,
  },
  timeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  routeStopName: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '500',
  },
  routeStopTime: {
    color: '#AAAAAA',
    fontSize: 14,
    marginLeft: 6,
  },
  countBadge: {
    backgroundColor: '#5345D9',
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
  },
  countBadgeText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 12,
  },
  busInfoFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 16,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#333333',
  },
  busInfoStat: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  busInfoStatText: {
    color: '#AAAAAA',
    fontSize: 12,
    marginLeft: 4,
  },
  viewRouteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(122, 95, 255, 0.15)',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 8,
  },
  viewRouteText: {
    color: '#7A5FFF',
    fontSize: 12,
    fontWeight: '500',
    marginRight: 4,
  },
});

export default BusInfoPage;