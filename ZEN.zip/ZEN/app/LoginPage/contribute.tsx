import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, ActivityIndicator, TouchableOpacity, StatusBar, Dimensions } from 'react-native';
import { initializeApp } from 'firebase/app';
import { getFirestore, doc, getDoc } from 'firebase/firestore';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import {db} from '../firebaseConfig';
import { useRoute } from '@react-navigation/native';
import { Picker } from "@react-native-picker/picker";
import { SafeAreaView } from "react-native-safe-area-context";

type ContributeDataType = {
  id: string;
  // Add other fields here as per your Firestore document structure
};


export default function ContributionsDashboard() {
  const [contributeData, setContributeData] = useState<{ id: string } | null>(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [activeTab, setActiveTab] = useState('details');
  const [refreshing, setRefreshing] = useState(false);
const route = useRoute<any>();
const { PassingMail } = route.params || { PassingMail: [] };

  useEffect(() => {
    fetchContributesData();
  }, []);

  const fetchContributesData = async () => {
    try {
      setLoading(true);
      
      // Direct reference to the Contributes document
      const contributesDocRef = doc(db, "Write", "User", PassingMail, "Contributes");
      
      // Get the document
      const docSnap = await getDoc(contributesDocRef);
      
      if (docSnap.exists()) {
        // Get the document data
        const data = {
          id: docSnap.id,
          ...docSnap.data()
        };
        setContributeData(data);
      } else {
        console.log("No such document!");
        setContributeData(null);
      }
      
      setLoading(false);
      setRefreshing(false);
    } catch (err) {
      console.error("Error fetching contributes data: ", err);
      setError('Failed to fetch data. Please try again.');
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    fetchContributesData();
  };

  const renderTabContent = () => {
    if (!contributeData) return null;

    switch (activeTab) {
      case 'details':
        return (
          <View style={styles.tabContent}>
            {Object.entries(contributeData)
              .filter(([key]) => key !== 'id' && key !== 'title')
              .map(([key, value], index) => (
                <LinearGradient
                  key={key}
                  colors={['#272536', '#1D1C2A']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={[styles.detailCard, { transform: [{ translateY: index * 5 }] }]}
                >
                  <View style={styles.detailCardHeader}>
                    <Text style={styles.detailLabel}>{key}</Text>
                    <View style={styles.shineEffect} />
                  </View>
                  <Text style={styles.detailValue}>
                    {typeof value === 'object' 
                      ? JSON.stringify(value) 
                      : String(value)}
                  </Text>
                </LinearGradient>
              ))
            }
          </View>
        );
      case 'stats':
        return (
          <View style={styles.tabContent}>
            <View style={styles.statsRow}>
              <LinearGradient
                colors={['#272536', '#1D1C2A']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={[styles.statCard, { flex: 1, marginRight: 8 }]}
              >
                <Text style={styles.statValue}>1</Text>
                <Text style={styles.statLabel}>Total Contributions</Text>
                <View style={styles.statIconContainer}>
                  <Ionicons name="document-text" size={40} color="rgba(122, 95, 255, 0.2)" />
                </View>
              </LinearGradient>
              
              <LinearGradient
                colors={['#272536', '#1D1C2A']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={[styles.statCard, { flex: 1, marginLeft: 8 }]}
              >
                <Text style={styles.statValue}>
                  {Object.keys(contributeData).length - 1}
                </Text>
                <Text style={styles.statLabel}>Data Points</Text>
                <View style={styles.statIconContainer}>
                  <Ionicons name="analytics" size={40} color="rgba(122, 95, 255, 0.2)" />
                </View>
              </LinearGradient>
            </View>
            
            <LinearGradient
              colors={['#272536', '#1D1C2A']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.activityCard}
            >
              <Text style={styles.activityTitle}>Activity Score</Text>
              <View style={styles.activityGraph}>
                <View style={styles.activityBarContainer}>
                  <View style={[styles.activityBar, { height: '80%', backgroundColor: '#7A5FFF' }]} />
                  <Text style={styles.activityBarLabel}>Mon</Text>
                </View>
                <View style={styles.activityBarContainer}>
                  <View style={[styles.activityBar, { height: '60%', backgroundColor: '#6B54EA' }]} />
                  <Text style={styles.activityBarLabel}>Tue</Text>
                </View>
                <View style={styles.activityBarContainer}>
                  <View style={[styles.activityBar, { height: '40%', backgroundColor: '#5C49D6' }]} />
                  <Text style={styles.activityBarLabel}>Wed</Text>
                </View>
                <View style={styles.activityBarContainer}>
                  <View style={[styles.activityBar, { height: '75%', backgroundColor: '#7A5FFF' }]} />
                  <Text style={styles.activityBarLabel}>Thu</Text>
                </View>
                <View style={styles.activityBarContainer}>
                  <View style={[styles.activityBar, { height: '90%', backgroundColor: '#6B54EA' }]} />
                  <Text style={styles.activityBarLabel}>Fri</Text>
                </View>
                <View style={styles.activityBarContainer}>
                  <View style={[styles.activityBar, { height: '30%', backgroundColor: '#5C49D6' }]} />
                  <Text style={styles.activityBarLabel}>Sat</Text>
                </View>
                <View style={styles.activityBarContainer}>
                  <View style={[styles.activityBar, { height: '55%', backgroundColor: '#7A5FFF' }]} />
                  <Text style={styles.activityBarLabel}>Sun</Text>
                </View>
              </View>
            </LinearGradient>
          </View>
        );
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.darkContainer}>
        <StatusBar barStyle="light-content" backgroundColor="#171621" />
        <LinearGradient
          colors={['#171621', '#13121B']}
          style={styles.centered}
        >
          <View style={styles.loadingIndicator}>
            <ActivityIndicator size="large" color="#7A5FFF" />
          </View>
          <Text style={styles.loadingText}>Loading Contributions....</Text>
        </LinearGradient>
      </SafeAreaView>
    );
  }

  if (error) {
    return (
      <SafeAreaView style={styles.darkContainer}>
        <StatusBar barStyle="light-content" backgroundColor="#171621" />
        <LinearGradient
          colors={['#171621', '#13121B']}
          style={styles.centered}
        >
          <View style={styles.errorIconContainer}>
            <Ionicons name="alert-circle" size={48} color="#FF5A5F" />
          </View>
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity 
            style={styles.retryButton} 
            onPress={fetchContributesData}
          >
            <LinearGradient
              colors={['#7A5FFF', '#5345D9']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.retryButtonGradient}
            >
              <Text style={styles.retryButtonText}>Try Again</Text>
            </LinearGradient>
          </TouchableOpacity>
        </LinearGradient>
      </SafeAreaView>
    );
  }

  if (!contributeData) {
    return (
      <SafeAreaView style={styles.darkContainer}>
        <StatusBar barStyle="light-content" backgroundColor="#171621" />
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Contributions</Text>
          <TouchableOpacity onPress={handleRefresh} style={styles.refreshButton}>
            <Ionicons name="refresh" size={24} color="#7A5FFF" />
          </TouchableOpacity>
        </View>
        <LinearGradient
          colors={['#171621', '#13121B']}
          style={styles.emptyContainer}
        >
          <View style={styles.emptyIconContainer}>
            <Ionicons name="document-text-outline" size={64} color="#5345D9" />
          </View>
          <Text style={styles.emptyText}>No contribution data found</Text>
          <TouchableOpacity style={styles.addButton}>
            <LinearGradient
              colors={['#7A5FFF', '#5345D9']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.addButtonGradient}
            >
              <Ionicons name="add" size={22} color="#FFFFFF" />
              <Text style={styles.addButtonText}>Create Contribution</Text>
            </LinearGradient>
          </TouchableOpacity>
        </LinearGradient>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.darkContainer}>
      <StatusBar barStyle="light-content" backgroundColor="#171621" />
      
      <LinearGradient
        colors={['#7A5FFF', '#5345D9']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={styles.headerGradient}
      >
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Contributions</Text>
          <TouchableOpacity onPress={handleRefresh} style={styles.refreshButton}>
            <Ionicons name="refresh" size={24} color="#FFFFFF" />
          </TouchableOpacity>
        </View>
      </LinearGradient>

      {refreshing && (
        <View style={styles.refreshIndicator}>
          <ActivityIndicator size="small" color="#7A5FFF" />
        </View>
      )}

      <LinearGradient
        colors={['#272536', '#1D1C2A']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.summaryCard}
      >
        <View style={styles.summaryHeader}>
          <Text style={styles.summaryTitle}>Welcome {PassingMail?.split('@')[0].replace(/[0-9]/g, '').replace(/^./, (char:string) => char.toUpperCase()) || "User"}</Text>
          <View style={styles.badgeContainer}>
            <LinearGradient colors={['#7A5FFF', '#5345D9']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.badgeGradient}>
              <Text style={styles.badgeText}>Active</Text>
            </LinearGradient>
          </View>
        </View>
        
        <View style={styles.summaryBody}>
          <View style={styles.summaryItem}>
            <View style={styles.summaryIconContainer}>
              <Ionicons name="checkmark-circle" size={24} color="#7A5FFF" />
            </View>
            <Text style={styles.summaryText}>Verified</Text>
          </View>
          
          <View style={styles.divider} />
          
          <View style={styles.summaryItem}>
            <View style={styles.summaryIconContainer}>
              <Ionicons name="time-outline" size={24} color="#7A5FFF" />
            </View>
            <Text style={styles.summaryText}>Updated recently</Text>
          </View>
        </View>
      </LinearGradient>

      <View style={styles.tabBar}>
        <TouchableOpacity 
          style={[styles.tabButton, activeTab === 'details' && styles.activeTabButton]} 
          onPress={() => setActiveTab('details')}
        >
          <Ionicons 
            name="list" 
            size={20} 
            color={activeTab === 'details' ? '#7A5FFF' : '#6E6A8A'} 
          />
          <Text style={[styles.tabText, activeTab === 'details' && styles.activeTabText]}>
            Details
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.tabButton, activeTab === 'stats' && styles.activeTabButton]} 
          onPress={() => setActiveTab('stats')}
        >
          <Ionicons 
            name="stats-chart" 
            size={20} 
            color={activeTab === 'stats' ? '#7A5FFF' : '#6E6A8A'} 
          />
          <Text style={[styles.tabText, activeTab === 'stats' && styles.activeTabText]}>
            Stats
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView 
        style={styles.content}
        contentContainerStyle={styles.contentContainer}
        showsVerticalScrollIndicator={false}
      >
        {renderTabContent()}
      </ScrollView>

      <View style={styles.footer}>
        <TouchableOpacity style={styles.actionButton}>
          <LinearGradient
            colors={['#7A5FFF', '#5345D9']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.actionButtonGradient}
          >
            <Ionicons name="create-outline" size={20} color="#FFFFFF" />
            <Text style={styles.actionButtonText}>Edit Contribution</Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  darkContainer: {
    flex: 1,
    backgroundColor: '#171621',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  loadingIndicator: {
    height: 80,
    width: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(122, 95, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerGradient: {
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    shadowColor: '#7A5FFF',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 10,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  refreshButton: {
    padding: 8,
  },
  refreshIndicator: {
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  summaryCard: {
    margin: 16,
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  summaryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  summaryTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    flex: 1,
  },
  badgeContainer: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  badgeGradient: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  badgeText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  summaryBody: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  summaryItem: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  summaryIconContainer: {
    height: 36,
    width: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(122, 95, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  summaryText: {
    fontSize: 14,
    color: '#B9B6CC',
  },
  divider: {
    width: 1,
    height: 24,
    backgroundColor: '#2D2C3B',
    marginHorizontal: 12,
  },
  tabBar: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    backgroundColor: '#1D1C2A',
    borderRadius: 12,
    marginHorizontal: 16,
    marginBottom: 8,
  },
  tabButton: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 12,
  },
  activeTabButton: {
    borderBottomWidth: 2,
    borderBottomColor: '#7A5FFF',
  },
  tabText: {
    marginLeft: 8,
    fontSize: 14,
    color: '#6E6A8A',
  },
  activeTabText: {
    color: '#7A5FFF',
    fontWeight: '600',
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    paddingBottom: 20,
  },
  tabContent: {
    padding: 16,
  },
  detailCard: {
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#7A5FFF',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
  },
  detailCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  detailLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#7A5FFF',
    marginBottom: 6,
  },
  detailValue: {
    fontSize: 16,
    color: '#B9B6CC',
  },
  shineEffect: {
    position: 'absolute',
    top: -10,
    right: -10,
    height: 20,
    width: 20,
    borderRadius: 10,
    backgroundColor: 'rgba(122, 95, 255, 0.3)',
  },
  statsRow: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  statCard: {
    borderRadius: 16,
    padding: 16,
    shadowColor: '#7A5FFF',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
    height: 120,
    overflow: 'hidden',
  },
  statValue: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  statLabel: {
    fontSize: 14,
    color: '#B9B6CC',
  },
  statIconContainer: {
    position: 'absolute',
    right: -10,
    bottom: -10,
    opacity: 0.5,
  },
  activityCard: {
    borderRadius: 16,
    padding: 16,
    shadowColor: '#7A5FFF',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
  },
  activityTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 16,
  },
  activityGraph: {
    flexDirection: 'row',
    height: 150,
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    paddingBottom: 25,
  },
  activityBarContainer: {
    alignItems: 'center',
    width: 30,
  },
  activityBar: {
    width: 8,
    borderRadius: 4,
  },
  activityBarLabel: {
    position: 'absolute',
    bottom: 0,
    fontSize: 12,
    color: '#B9B6CC',
  },
  historyItem: {
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    flexDirection: 'row',
    shadowColor: '#7A5FFF',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
  },
  historyTimeline: {
    width: 20,
    alignItems: 'center',
  },
  historyDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#7A5FFF',
  },
  historyLine: {
    width: 2,
    flex: 1,
    backgroundColor: '#2D2C3B',
    marginTop: 5,
  },
  historyContent: {
    flex: 1,
    paddingLeft: 10,
  },
  historyDate: {
    fontSize: 14,
    fontWeight: '600',
    color: '#7A5FFF',
    marginBottom: 4,
  },
  historyAction: {
    fontSize: 16,
    fontWeight: '500',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  historyDetails: {
    fontSize: 14,
    color: '#B9B6CC',
  },
  footer: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#2D2C3B',
  },
  actionButton: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  actionButtonGradient: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 14,
    borderRadius: 12,
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  loadingText: {
    color: '#B9B6CC',
    fontSize: 18,
    marginTop: 16,
  },
  errorText: {
    color: '#FF5A5F',
    fontSize: 18,
    textAlign: 'center',
    marginTop: 12,
    marginBottom: 16,
  },
  errorIconContainer: {
    height: 80,
    width: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(255, 90, 95, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  retryButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginTop: 8,
  },
  retryButtonGradient: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
  },
  retryButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyIconContainer: {
    height: 120,
    width: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(122, 95, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 18,
    color: '#B9B6CC',
    marginBottom: 24,
  },
  addButton: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  addButtonGradient: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 12,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
});