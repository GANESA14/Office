import * as Linking from "expo-linking";
import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet, Modal, ActivityIndicator, StatusBar } from "react-native";
import { getAuth, signOut } from "firebase/auth";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons,FontAwesome5 ,AntDesign,MaterialIcons,MaterialCommunityIcons,FontAwesome6} from "@expo/vector-icons";
import { navigate } from "expo-router/build/global-state/routing";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { LinearGradient } from "expo-linear-gradient";
import * as WebBrowser from "expo-web-browser";
import { useRoute } from '@react-navigation/native';

type NavigationProp = NativeStackNavigationProp<RootStackParamList, "Index">;

type RootStackParamList = {
  Index: undefined;
  hello: undefined;
  ForgotPassword: undefined;
  AddMore: undefined;
  Add:{PassingMail:[]};
  Contributions:{PassingMail:[]};
  AboutPage:undefined;
};

const Hello = () => {
  const auth = getAuth();
  const [loading, setLoading] = useState(false);
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
    const route = useRoute<any>();
  const { userEmail } = route.params || { userEmail: [] };
  var PassingMail=userEmail;
  const handleLogout = async () => {
    setLoading(true);
    try {
      await signOut(auth);
      await AsyncStorage.removeItem("user");
      navigation.reset({
        index: 0,
        routes: [{ name: "Index" as keyof RootStackParamList }],
      });
      
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
      setShowLogoutModal(false);
    }
  };
  
  const navigateToAdd = () => {
    navigation.navigate("AddMore");
  };
  const navigateToAbout =()=>{
    navigation.navigate('AboutPage');
  }
  const navigateToContributes =()=>{
    navigation.navigate('Contributions',{PassingMail});
  }
  const openHelpLink = async() => {
        await WebBrowser.openBrowserAsync("https://github.com/projectwork11421");
  };
const colored='#7A5FFF';
const seccolor=colored;
  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#121212" />
      <LinearGradient
        colors={['#7A5FFF', '#5345D9']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.header}
      >
        <Text style={styles.headerTitle}>Profile</Text>
        <View style={styles.avatarContainer}>
          <LinearGradient
            colors={['#5345D9', '#7A5FFF']}
            style={styles.avatarGradient}
          >
            <Text style={styles.avatarText}>
            {userEmail?.[0]?.toUpperCase() || "U"}
            </Text>
          </LinearGradient>
          <View style={styles.userInfo}>
            <Text style={styles.userName}>
            {userEmail?.split('@')[0].replace(/[0-9]/g, '').replace(/^./, (char) => char.toUpperCase()) || "User"}
            </Text>
            <Text style={styles.userEmail}>{userEmail}</Text>
          </View>
        </View>
      </LinearGradient>

      <View style={styles.menuSection}>
        <Text style={styles.menuSectionTitle}>Settings</Text>
        <TouchableOpacity style={styles.menuItem} onPress={()=>{navigation.navigate('Add',{PassingMail})}}>
          <View style={styles.menuIconContainer}>
          <FontAwesome5 name="bus-alt" size={20} color={colored} />
          </View>
            <Text style={styles.menuText}>Buses & Routes</Text>
          <Ionicons name="chevron-forward" size={20} color={seccolor} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.menuItem} onPress={navigateToContributes}>
          <View style={styles.menuIconContainer}>
          <FontAwesome6 name="add" size={24} color={colored} />
          </View>
          <Text style={styles.menuText}>Contributes</Text>
          <Ionicons name="chevron-forward" size={20} color={seccolor} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.menuItem} onPress={navigateToAbout}>
          <View style={styles.menuIconContainer}>
          <MaterialIcons name="policy" size={22} color={colored} />
          </View>
          <Text style={styles.menuText}>About Policy</Text>
          <Ionicons name="chevron-forward" size={20} color={seccolor} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.menuItem} onPress={navigateToAdd}>
          <View style={styles.menuIconContainer}>
            <Ionicons name="add-circle-outline" size={22} color={colored}/>
          </View>
          <Text style={styles.menuText}>Payment Details</Text>
          <Ionicons name="chevron-forward" size={20} color={seccolor} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.menuItem} onPress={openHelpLink}>
          <View style={styles.menuIconContainer}>
          <AntDesign name="customerservice" size={20} color={colored}/>
          </View>
          <Text style={styles.menuText}>Help & Support</Text>
          <Ionicons name="chevron-forward" size={20} color={seccolor} />
        </TouchableOpacity>
      </View>

      <TouchableOpacity
        style={styles.logoutButton}
        onPress={() => setShowLogoutModal(true)}
      >
        <LinearGradient
          colors={['#7A5FFF', '#5345D9']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={styles.logoutGradient}
        >
          <Ionicons name="log-out-outline" size={22} color="#fff" />
          <Text style={styles.logoutText}>Logout</Text>
        </LinearGradient>
      </TouchableOpacity>

      <Modal visible={showLogoutModal} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <LinearGradient
              colors={['#7A5FFF', '#5345D9']}
              style={styles.modalIconContainer}
            >
              <Ionicons name="log-out-outline" size={30} color="#fff" />
            </LinearGradient>
            <Text style={styles.modalTitle}>Logout</Text>
            <Text style={styles.modalMessage}>
              Are you sure you want to logout?
            </Text>
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowLogoutModal(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.confirmButton]}
                onPress={handleLogout}
              >
                    <Text style={styles.confirmButtonText}>Logout</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: "#121212" 
  },
  header: {
    padding: 20,
    paddingTop: 60,
    borderBottomLeftRadius: 25,
    borderBottomRightRadius: 25,
    elevation: 8,
    shadowColor: "#7A5FFF",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  headerTitle: { 
    fontSize: 28, 
    fontWeight: "bold", 
    color: "#fff",
    marginBottom: 20
  },
  avatarContainer: { 
    flexDirection: "row", 
    alignItems: "center",
    marginTop: 10
  },
  avatarGradient: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  avatarText: { 
    fontSize: 32, 
    color: "#fff", 
    fontWeight: "bold" 
  },
  userInfo: { 
    marginLeft: 20 
  },
  userName: { 
    fontSize: 24, 
    fontWeight: "600", 
    color: "#fff", 
    marginBottom: 5 
  },
  userEmail: { 
    fontSize: 16, 
    color: "rgba(255,255,255,0.8)" 
  },
  menuSection: { 
    backgroundColor: "#1E1E1E", 
    margin: 20,
    borderRadius: 15,
    padding: 20,
    elevation: 4,
    shadowColor: "#7A5FFF",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  menuSectionTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: "#7A5FFF",
    marginBottom: 15,
    marginLeft: 10
  },
  menuItem: { 
    flexDirection: "row", 
    alignItems: "center", 
    paddingVertical: 15, 
    borderBottomWidth: 1, 
    borderBottomColor: "rgba(255,255,255,0.1)" 
  },
  menuIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(122, 95, 255, 0.15)",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 10
  },
  menuText: { 
    flex: 1, 
    marginLeft: 5, 
    fontSize: 16, 
    color: "#fff" 
  },
  logoutButton: { 
    margin: 20,
    marginTop: 10,
    borderRadius: 12,
    overflow: "hidden",
    elevation: 4,
    shadowColor: "#7A5FFF",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  logoutGradient: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
  },
  logoutText: { 
    marginLeft: 10, 
    fontSize: 16, 
    color: "#fff", 
    fontWeight: "600" 
  },
  modalOverlay: { 
    flex: 1, 
    backgroundColor: "rgba(0, 0, 0, 0.7)", 
    justifyContent: "center", 
    alignItems: "center" 
  },
  modalContent: { 
    backgroundColor: "#1E1E1E", 
    borderRadius: 20, 
    padding: 25, 
    width: "80%", 
    alignItems: "center",
    borderWidth: 1,
    borderColor: "rgba(122, 95, 255, 0.3)" 
  },
  modalIconContainer: {
    width: 70,
    height: 70,
    borderRadius: 35,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 15
  },
  modalTitle: { 
    fontSize: 24, 
    fontWeight: "bold", 
    color: "#fff", 
    marginTop: 10, 
    marginBottom: 10 
  },
  modalMessage: { 
    fontSize: 16, 
    color: "rgba(255,255,255,0.7)", 
    textAlign: "center", 
    marginBottom: 25 
  },
  modalButtons: { 
    flexDirection: "row", 
    justifyContent: "space-between", 
    width: "100%" 
  },
  modalButton: { 
    flex: 1, 
    paddingVertical: 12, 
    borderRadius: 10, 
    marginHorizontal: 5,
    overflow: "hidden" 
  },
  cancelButton: { 
    backgroundColor: "rgba(255,255,255,0.1)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.2)" 
  },
  confirmButton: { 
    overflow: "hidden",padding:10,borderRadius:15,
    backgroundColor:'#5345D9'
  },
  confirmGradient: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12
  },
  cancelButtonText: { 
    color: "#fff", 
    textAlign: "center", 
    fontWeight: "600", 
    fontSize: 16 
  },
  confirmButtonText: { 
    color: "white", 
    textAlign: "center", 
    fontWeight: "600", 
    fontSize: 16 
  },
});

export default Hello;