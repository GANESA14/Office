import Feather from '@expo/vector-icons/Feather';
import React, { useState, useEffect } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ActivityIndicator, StatusBar, KeyboardAvoidingView, Platform, TouchableWithoutFeedback, Keyboard, Animated
} from "react-native";
import { getAuth, sendPasswordResetEmail } from "firebase/auth";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";

type NavigationProp = NativeStackNavigationProp<RootStackParamList, "ForgotPassword">;
type RootStackParamList = {
  ForgotPassword: undefined;
  Index: undefined;
};
type ToastProps = {
  visible: boolean;
  message: string;
  type?: "success" | "error" | "info"; // Optional with default value
};
const Toast: React.FC<ToastProps> = ({ visible, message, type = "success" }) => {
  const [fadeAnim] = useState(new Animated.Value(0));
  
  useEffect(() => {
    if (visible) {
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start();
    } else {
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }).start();
    }
  }, [visible]);
  
  if (!message) return null;
  
  return (
    <Animated.View
      style={[
        styles.toast,
        {
          backgroundColor: type === "success" ? "#10B981" : "#EF4444",
          opacity: fadeAnim,
          transform: [
            {
              translateY: fadeAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [20, 0],
              }),
            },
          ],
        },
      ]}
    >
      <Ionicons 
        name={type === "success" ? "checkmark-circle" : "alert-circle"} 
        size={20} 
        color="#FFFFFF" 
      />
      <Text style={styles.toastText}>{message}</Text>
    </Animated.View>
  );
};

export default function ForgotPassword() {
  const navigation = useNavigation<NavigationProp>();
  const auth = getAuth();
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({ text: "", type: "error" });
  const [emailFocused, setEmailFocused] = useState(false);

  const handleResetPassword = async () => {
    if (!email) {
      setMessage({ text: "Please enter your email address.", type: "error" });
      return;
    }
    
    setLoading(true);
    try {
      await sendPasswordResetEmail(auth, email);
      setMessage({ text: "Password reset email sent. Check your inbox.", type: "success" });
      setTimeout(() => {
        setMessage({ text: "", type: "success" });
      }, 3000);
    } catch (error: any) {
      setMessage({ text: error.message, type: "error" });
      setTimeout(() => {
        setMessage({ text: "", type: "error" });
      }, 3000);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor="#121212" />
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          style={styles.container}
        >
          <View style={styles.contentContainer}>
            <View style={styles.logoContainer}>
              <View style={styles.logoCircle}>
                <Ionicons name="lock-open-outline" size={32} color="#7A5FFF" />
              </View>
            </View>
            
            <Text style={styles.header}>Reset Password</Text>
            <Text style={styles.subHeader}>
              Enter your email address and we'll send you a link to reset your password
            </Text>

            <View style={[
              styles.inputWrapper,
              emailFocused && styles.inputWrapperFocused
            ]}>
              <Ionicons 
                name="mail-outline" 
                size={22} 
                color={emailFocused ? "#7A5FFF" : "#9CA3AF"} 
              />
              <TextInput 
                placeholder="Email address" 
                value={email} 
                onChangeText={setEmail} 
                style={styles.input} 
                keyboardType="email-address" 
                autoCapitalize="none" 
                placeholderTextColor="#9CA3AF" 
                onFocus={() => setEmailFocused(true)} 
                onBlur={() => setEmailFocused(false)}
              />
            </View>

            <Toast 
              visible={message.text !== ""} 
              message={message.text} 
              type={message.type as "success" | "error" | "info"} 
            />

            <TouchableOpacity 
              style={styles.button} 
              onPress={handleResetPassword} 
              disabled={loading}
              activeOpacity={0.8}
            >
              <LinearGradient
                colors={['#5345D9', '#7A5FFF']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.buttonGradient}
              >
                {loading ? (
                  <ActivityIndicator color="#FFFFFF" size="small" />
                ) : (
                  <Text style={styles.buttonText}>Send Reset Link</Text>
                )}
              </LinearGradient>
            </TouchableOpacity>

            <View style={styles.footerContainer}>
              <Text style={styles.footerText}>Remember your password? </Text>
              <TouchableOpacity onPress={() => navigation.goBack()}>
                <Text style={styles.footerLink}>Sign In</Text>
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </TouchableWithoutFeedback>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { 
    flex: 1, 
    backgroundColor: "#121212",
  },
  container: {
    flex: 1,
    backgroundColor: "#121212",
  },
  contentContainer: { 
    flex: 1, 
    padding: 24, 
    justifyContent: "center", 
  },
  backButton: { 
    position: "absolute", 
    top: 20, 
    left: 16, 
    padding: 8, 
    zIndex: 10,
  },
  logoContainer: { 
    alignItems: "center", 
    marginBottom: 32,
  },
  logoCircle: { 
    width: 80, 
    height: 80, 
    borderRadius: 40, 
    backgroundColor: "#1E1E1E", 
    justifyContent: "center", 
    alignItems: "center", 
    marginBottom: 16,
  },
  header: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#FFFFFF",
    textAlign: "center",
    marginBottom: 12,
  },
  subHeader: {
    fontSize: 16,
    color: "#E0E0E0",
    textAlign: "center",
    marginBottom: 32,
    lineHeight: 22,
    paddingHorizontal: 16,
  },
  inputWrapper: { 
    flexDirection: "row", 
    alignItems: "center", 
    backgroundColor: "#1E1E1E", 
    borderWidth: 1, 
    borderColor: "#333333", 
    borderRadius: 12, 
    marginBottom: 24, 
    paddingHorizontal: 16, 
    height: 56,
  },
  inputWrapperFocused: { 
    borderColor: "#7A5FFF", 
    borderWidth: 1.5, 
    backgroundColor: "#1E1E1E",
  },
  input: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 10,
    color: "#FFFFFF",
    fontSize: 16,
  },
  toast: { 
    flexDirection: "row", 
    alignItems: "center", 
    justifyContent: "center", 
    paddingVertical: 12, 
    paddingHorizontal: 16, 
    borderRadius: 12, 
    marginBottom: 24,
  },
  toastText: { 
    color: "#FFFFFF", 
    fontSize: 14, 
    fontWeight: "500", 
    marginLeft: 8,
  },
  button: { 
    borderRadius: 12, 
    overflow: "hidden",  
    shadowColor: "#5345D9", 
    shadowOffset: { 
      width: 0, 
      height: 4,
    }, 
    shadowOpacity: 0.5, 
    shadowRadius: 8, 
    elevation: 6, 
    marginBottom: 24,
  },
  buttonGradient: { 
    paddingVertical: 16, 
    alignItems: "center", 
    justifyContent: "center",
  },
  buttonText: { 
    color: "#FFFFFF", 
    fontSize: 16, 
    fontWeight: "600",
  },
  footerContainer: { 
    flexDirection: "row", 
    justifyContent: "center", 
    alignItems: "center",
  },
  footerText: {
    fontSize: 14,
    color: "#E0E0E0",
  },
  footerLink: {
    fontSize: 14,
    fontWeight: "600",
    color: "#7A5FFF",
  },
});