import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { initializeAuth, getReactNativePersistence } from "firebase/auth";
import AsyncStorage from "@react-native-async-storage/async-storage";

const firebaseConfig = {
  apiKey: "AIzaSyBGIb9fx-UCM24N5-bzlL-sJSMPNhWA1LI",
  authDomain: "testing-bcf2f.firebaseapp.com",
  projectId: "testing-bcf2f",
  storageBucket: "testing-bcf2f.firebasestorage.app",
  messagingSenderId: "37064493586",
  appId: "1:37064493586:web:9837afd194993cf841e6cb",
  measurementId: "G-LJS9C2FJCE"
};

// Initialize Firebase app
const app = initializeApp(firebaseConfig);

// Export Firebase services for easy access
export const db = getFirestore(app); // Firestore Database
// export const auth = getAuth(app); // Firebase Authentication

export const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(AsyncStorage)
});
export const storage = getStorage(app); // Firebase Storage
export default app;
