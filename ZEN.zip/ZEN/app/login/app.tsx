import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { TouchableOpacity } from 'react-native';
import Login from '../LoginPage/Login';
import Profile from '../LoginPage/Profile';
import ForgotPassword from '../LoginPage/ForgotPassword';
import AddScreen from '../LoginPage/Add';
import FontAwesome5 from '@expo/vector-icons/FontAwesome5';
const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Index">
        <Stack.Screen name="Index" component={Login} options={{ headerShown: false }} />
        <Stack.Screen name="hello" component={Profile} />
        <Stack.Screen name="ForgotPassword" component={ForgotPassword} options={{ title: "Reset Password" }} />
        <Stack.Screen 
          name="Add" 
          component={AddScreen} 
          options={({ navigation }) => ({
            title: "Add",
            headerRight: () => (
              <TouchableOpacity onPress={() => navigation.navigate("hello")} style={{ marginRight: 10 }}>
                <FontAwesome5 name="user-circle" size={24} color="black" />
              </TouchableOpacity>
            ),
          })}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
