import React, { useState, useEffect } from "react";
import { View, Text, TextInput, TouchableOpacity, Animated, TouchableWithoutFeedback, Keyboard, Modal, ActivityIndicator, StyleSheet,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { initializeApp, getApps, getApp } from "firebase/app";
import {getAuth,onAuthStateChanged,signInWithEmailAndPassword,createUserWithEmailAndPassword,sendEmailVerification,signOut,
} from "firebase/auth";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";

// Types
type NavigationProp = NativeStackNavigationProp<RootStackParamList, "Index">;
type RootStackParamList = {
  Index: undefined;
  hello: undefined;
  ForgotPassword:undefined;
  Add:undefined;
};

// Toast Component
const Toast = ({ visible, message, type = "success", onClose }) => {
  useEffect(() => {
    if (visible) {
      const timer = setTimeout(() => {
        onClose();
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [visible]);

  if (!visible) return null;

  return (
    <Animated.View
      style={[
        styles.toast,
        {
          backgroundColor: type === "success" ? "#4CAF50" : "#f44336",
        },
      ]}
    >
      <Text style={styles.toastText}>{message}</Text>
    </Animated.View>
  );
};

// Modal Component
const CustomModal = ({ visible, title, message, onClose }) => {
  return (
    <Modal transparent visible={visible} animationType="fade">
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>{title}</Text>
          <Text style={styles.modalMessage}>{message}</Text>
          <TouchableOpacity style={styles.modalButton} onPress={onClose}>
            <Text style={styles.modalButtonText}>OK</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

// Loading Component
const LoadingSpinner = ({ visible }) => {
  if (!visible) return null;

  return (
    <View style={styles.spinnerOverlay}>
      <View style={styles.spinnerContainer}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.spinnerText}>Please wait...</Text>
      </View>
    </View>
  );
};

const firebaseConfig = {
  apiKey: "AIzaSyBjZwkq0JNo8q8JE8alMGzprDWKMx3-kis",
  authDomain: "bus-routes-b7f5b.firebaseapp.com",
  projectId: "bus-routes-b7f5b",
  storageBucket: "bus-routes-b7f5b.firebasestorage.app",
  messagingSenderId: "287910459440",
  appId: "1:287910459440:web:d0c58022cadc19e7e8d5f5",
  measurementId: "G-ESKM1H0QX1",
};

// Initialize Firebase properly
let app;
if (getApps().length === 0) {
  app = initializeApp(firebaseConfig);
} else {
  app = getApp();
}
const auth = getAuth(app);

export default function App() {
  const navigation = useNavigation<NavigationProp>();
  const [user, setUser] = useState<any>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isSignup, setIsSignup] = useState(false);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState({ visible: false, message: "", type: "success" });
  const [modal, setModal] = useState({ visible: false, title: "", message: "" });

  useEffect(() => {
    const loadUser = async () => {
      const storedUser = await AsyncStorage.getItem("user");
      if (storedUser) {
        setUser(JSON.parse(storedUser));
        navigation.reset({
          index: 0,
          routes: [{ name: "Add" }],
        });
      }
    };
    loadUser();

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setUser(user);
        await AsyncStorage.setItem("user", JSON.stringify(user));

        if (user.emailVerified) {
          navigation.reset({
            index: 0,
            routes: [{ name: "Add" }],
          });
        } else {
          setModal({
            visible: true,
            title: "Verification Required",
            message: "Please verify your email before logging in.",
          });
          signOut(auth);
        }
      } else {
        setUser(null);
        await AsyncStorage.removeItem("user");
      }
    });

    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    if (!email || !password) {
      setModal({
        visible: true,
        title: "Missing Fields",
        message: "Please fill in all fields.",
      });
      return;
    }

    setLoading(true);
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      if (!user.emailVerified) {
        setModal({
          visible: true,
          title: "Verification Required",
          message: "Please verify your email before logging in.",
        });
        return;
      }

      await AsyncStorage.setItem("user", JSON.stringify(user));
      setToast({
        visible: true,
        message: "Logged in successfully!",
        type: "success",
      });

      navigation.reset({
        index: 0,
        routes: [{ name: "AddScreen" }],
      });
    } catch (error) {
      setModal({
        visible: true,
        title: "Login Failed",
        message: "Invalid email or password. Please try again.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async () => {
    if (!email || !password || !confirmPassword) {
      setModal({
        visible: true,
        title: "Missing Fields",
        message: "Please fill in all fields.",
      });
      return;
    }

    if (password !== confirmPassword) {
      setModal({
        visible: true,
        title: "Password Mismatch",
        message: "Passwords do not match. Please try again.",
      });
      return;
    }

    setLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      await sendEmailVerification(user);
      setModal({
        visible: true,
        title: "Verification Email Sent",
        message: "Please check your email to verify your account.",
      });
      await AsyncStorage.setItem("user", JSON.stringify(user));
    } catch (error) {
      setModal({
        visible: true,
        title: "Sign Up Failed",
        message: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <View style={styles.container}>
        {user ? (
          <View style={styles.welcomeContainer}>
            <Text style={styles.welcomeText}>Welcome, {user.email}!</Text>
          </View>
        ) : (
          <View style={styles.authContainer}>
            <Text style={styles.headerText}>Welcome Back</Text>
            <Text style={styles.subHeaderText}>
              {isSignup ? "Create an account to get started" : "Sign in to continue"}
            </Text>

            <View style={styles.toggleContainer}>
              <TouchableOpacity
                style={[styles.toggleButton, !isSignup && styles.toggleButtonActive]}
                onPress={() => setIsSignup(false)}
              >
                <Text style={[styles.toggleButtonText, !isSignup && styles.toggleButtonTextActive]}>
                  Login
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.toggleButton, isSignup && styles.toggleButtonActive]}
                onPress={() => setIsSignup(true)}
              >
                <Text style={[styles.toggleButtonText, isSignup && styles.toggleButtonTextActive]}>
                  Sign Up
                </Text>
              </TouchableOpacity>
            </View>

            <View style={styles.inputContainer}>
              <View style={styles.inputWrapper}>
                <Ionicons name="mail-outline" size={20} color="#666" />
                <TextInput
                  placeholder="Email"
                  value={email}
                  onChangeText={setEmail}
                  style={styles.input}
                  autoCapitalize="none"
                  keyboardType="email-address"
                />
              </View>

              <View style={styles.inputWrapper}>
                <Ionicons name="lock-closed-outline" size={20} color="#666" />
                <TextInput
                  placeholder="Password"
                  secureTextEntry={!showPassword}
                  value={password}
                  onChangeText={setPassword}
                  style={styles.input}
                />
                <TouchableOpacity
                  onPress={() => setShowPassword(!showPassword)}
                  style={styles.eyeIcon}
                >
                  <Ionicons
                    name={showPassword ? "eye-off-outline" : "eye-outline"}
                    size={20}
                    color="#666"
                  />
                </TouchableOpacity>
              </View>
<View>
<TouchableOpacity onPress={() => navigation.navigate("ForgotPassword")}>
  <Text style={{ color: "#007AFF", textAlign: "center", marginTop: 10 }}>Forgot Password?</Text>
</TouchableOpacity>

</View>
              {isSignup && (
                <View style={styles.inputWrapper}>
                  <Ionicons name="lock-closed-outline" size={20} color="#666" />
                  <TextInput
                    placeholder="Confirm Password"
                    secureTextEntry={!showConfirmPassword}
                    value={confirmPassword}
                    onChangeText={setConfirmPassword}
                    style={styles.input}
                  />
                  <TouchableOpacity
                    onPress={() => setShowConfirmPassword(!showConfirmPassword)}
                    style={styles.eyeIcon}
                  >
                    <Ionicons
                      name={showConfirmPassword ? "eye-off-outline" : "eye-outline"}
                      size={20}
                      color="#666"
                    />
                  </TouchableOpacity>
                </View>
              )}
            </View>

            <TouchableOpacity
              style={styles.button}
              onPress={isSignup ? handleSignup : handleLogin}
            >
              <Text style={styles.buttonText}>
                {isSignup ? "Create Account" : "Sign In"}
              </Text>
            </TouchableOpacity>
          </View>
        )}

        <LoadingSpinner visible={loading} />
        <Toast
          visible={toast.visible}
          message={toast.message}
          type={toast.type}
          onClose={() => setToast({ ...toast, visible: false })}
        />
        <CustomModal
          visible={modal.visible}
          title={modal.title}
          message={modal.message}
          onClose={() => setModal({ ...modal, visible: false })}
        />
      </View>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  welcomeContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
  },
  authContainer: {
    flex: 1,
    justifyContent: "center",
    padding: 20,
  },
  headerText: {
    fontSize: 32,
    fontWeight: "bold",
    color: "#333",
    textAlign: "center",
    marginBottom: 10,
  },
  subHeaderText: {
    fontSize: 16,
    color: "#666",
    textAlign: "center",
    marginBottom: 30,
  },
  toggleContainer: {
    flexDirection: "row",
    backgroundColor: "#f5f5f5",
    borderRadius: 25,
    marginBottom: 30,
    padding: 5,
  },
  toggleButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 20,
  },
  toggleButtonActive: {
    backgroundColor: "#007AFF",
  },
  toggleButtonText: {
    textAlign: "center",
    color: "#666",
    fontWeight: "600",
  },
  toggleButtonTextActive: {
    color: "#fff",
  },
  inputContainer: {
    marginBottom: 30,
  },
  inputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f5f5f5",
    borderRadius: 12,
    marginBottom: 15,
    paddingHorizontal: 15,
  },
  input: {
    flex: 1,
    paddingVertical: 15,
    paddingHorizontal: 10,
    color: "#333",
  },
  eyeIcon: {
    padding: 10,
  },
  button: {
    backgroundColor: "#007AFF",
    paddingVertical: 15,
    borderRadius: 12,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  buttonText: {
    color: "#fff",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "600",
  },
  spinnerOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0, 0, 0, 0.4)",
    justifyContent: "center",
    alignItems: "center",
  },
  spinnerContainer: {
    backgroundColor: "#fff",
    padding: 20,
    borderRadius: 10,
    alignItems: "center",
  },
  spinnerText: {
    marginTop: 10,
    color: "#666",
  },
  toast: {
    position: "absolute",
    bottom: 50,
    left: 20,
    right: 20,
    padding: 15,
    borderRadius: 8,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  toastText: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "500",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
},
modalContent: {
    backgroundColor: "#fff",
    borderRadius: 15,
    padding: 20,
    width: "80%",
    maxWidth: 400,
    shadowColor: "#000",
    shadowOffset: {
        width: 0,
        height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
},
modalTitle: {
    fontSize: 20,
    fontWeight: "600",
    color: "#333",
    marginBottom: 10,
    textAlign: "center",
},
modalMessage: {
    fontSize: 16,
    color: "#666",
    marginBottom: 20,
    textAlign: "center",
    lineHeight: 22,
},
modalButton: {
    backgroundColor: "#007AFF",
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 10,
    alignSelf: "center",
},
modalButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
    textAlign: "center",
},
});