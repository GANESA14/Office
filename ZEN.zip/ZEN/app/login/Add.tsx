import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useRoute } from '@react-navigation/native';

interface BusInfo {
  busName: string;
  busNumber: string;
  route: { stop: string; time: string }[]; 
}

const BusInfoPage: React.FC = () => {
  const [busName, setBusName] = useState<string>('');
  const [busNumber, setBusNumber] = useState<string>('');
  const [stops, setStops] = useState<{ stop: string; time: string }[]>([{ stop: '', time: '' }]);
  const [source, setSource] = useState<string>('');
  const [destination, setDestination] = useState<string>('');
  const [busList, setBusList] = useState<BusInfo[]>([]);
const route = useRoute<any>(); // 'any' is used to bypass strict typing for the route

  const [isSourceTimePickerVisible, setSourceTimePickerVisible] = useState<boolean>(false);
  const [isDestinationTimePickerVisible, setDestinationTimePickerVisible] = useState<boolean>(false);
  const [isStopTimePickerVisible, setStopTimePickerVisible] = useState<number | null>(null);

  const handleAddStop = () => {
    setStops([...stops, { stop: '', time: '' }]);
  };

  const handleStopChange = (text: string, index: number, field: 'stop' | 'time') => {
    const newStops = stops.map((stop, i) =>
      i === index ? { ...stop, [field]: text } : stop
    );
    setStops(newStops);
  };

  const handleDeleteStop = (index: number) => {
    const updatedStops = stops.filter((_, i) => i !== index);
    setStops(updatedStops);
  };

  const handleTimeConfirm = (time: Date, type: 'source' | 'destination' | 'stop' | null, stopIndex: number | null) => {
    const formattedTime = `${time.getHours()}:${time.getMinutes()}`;
    if (type === 'source') {
      setSource(formattedTime);
      setSourceTimePickerVisible(false);
    } else if (type === 'destination') {
      setDestination(formattedTime);
      setDestinationTimePickerVisible(false);
    } else if (type === 'stop' && stopIndex !== null) {
      const updatedStops = [...stops];
      updatedStops[stopIndex].time = formattedTime;
      setStops(updatedStops);
      setStopTimePickerVisible(null);
    }
  };

  const handleSubmit = () => {
    if (!source || !destination || !busName || !busNumber) {
      alert('Please fill out all the fields');
      return;
    }

    const route = [
      { stop: source, time: source }, // Include time for the source
      ...stops.filter((stop) => stop.stop.trim() !== ''), // Remove empty stops
      { stop: destination, time: destination }, // Include time for the destination
    ];

    const busInfo: BusInfo = {
      busName,
      busNumber,
      route,
    };

    setBusList([...busList, busInfo]);

    setBusName('');
    setBusNumber('');
    setStops([{ stop: '', time: '' }]);
    setSource('');
    setDestination('');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Bus Information</Text>
      <TextInput
        style={styles.input}
        placeholder="Bus Name"
        value={busName}
        onChangeText={setBusName}
      />
      <TextInput
        style={styles.input}
        placeholder="Bus Numbhger"
        value={busNumber}
        onChangeText={setBusNumber}
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input}
        placeholder="Source"
        value={source}
        editable={false} // Disable direct editing
      />
      <TouchableOpacity onPress={() => setSourceTimePickerVisible(true)} style={styles.button}>
        <Text style={styles.buttonText}>Select Source Time</Text>
      </TouchableOpacity>
      <TextInput
        style={styles.input}
        placeholder="Destination"
        value={destination}
        editable={false} // Disable direct editing
      />
      <TouchableOpacity onPress={() => setDestinationTimePickerVisible(true)} style={styles.button}>
        <Text style={styles.buttonText}>Select Destination Time</Text>
      </TouchableOpacity>
      <Text style={styles.subtitle}>Stops</Text>
      {stops.map((stop, index) => (
        <View key={index} style={styles.stopContainer}>
          <TextInput
            style={styles.input}
            placeholder={`Stop ${index + 1} Name`}
            value={stop.stop}
            onChangeText={(text) => handleStopChange(text, index, 'stop')}
          />
          <TouchableOpacity
            onPress={() => setStopTimePickerVisible(index)}
            style={styles.timePickerInput}
          >
            <Text>{stop.time || 'Select Time'}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => handleDeleteStop(index)}
            style={styles.deleteButton}
          >
            <Text style={styles.deleteButtonText}>Delete Stop</Text>
          </TouchableOpacity>
        </View>
      ))}
      <TouchableOpacity onPress={handleAddStop} style={styles.button}>
        <Text style={styles.buttonText}>Add Stop</Text>
      </TouchableOpacity>
      <Button title="Submit" onPress={handleSubmit} />
      <Text style={styles.subtitle}>Saved Bus List:</Text>
      {busList.map((bus, index) => (
        <View key={index} style={styles.busInfo}>
          <Text>Bus Name: {bus.busName}</Text>
          <Text>Bus Number: {bus.busNumber}</Text>
          <Text>
            Route:
            {bus.route && bus.route.length > 0
              ? bus.route
                  .map((stop) => `${stop.stop} (Time: ${stop.time || 'N/A'})`)
                  .join(', ')
              : 'No route available'}
          </Text>
        </View>
      ))}
      
      {/* Time pickers */}
      <DateTimePickerModal
        isVisible={isSourceTimePickerVisible}
        mode="time"
        onConfirm={(time) => handleTimeConfirm(time, 'source', null)}
        onCancel={() => setSourceTimePickerVisible(false)}
      />
      <DateTimePickerModal
        isVisible={isDestinationTimePickerVisible}
        mode="time"
        onConfirm={(time) => handleTimeConfirm(time, 'destination', null)}
        onCancel={() => setDestinationTimePickerVisible(false)}
      />
      {isStopTimePickerVisible !== null && (
        <DateTimePickerModal
          isVisible={true}
          mode="time"
          onConfirm={(time) => handleTimeConfirm(time, 'stop', isStopTimePickerVisible)}
          onCancel={() => setStopTimePickerVisible(null)}
        />
      )}
    </ScrollView>
  );
};
const styles = StyleSheet.create({
    container: {
      flexGrow: 1,
      padding: 24,
      backgroundColor: '#F8F9FA',
    },
    title: {
      fontSize: 28,
      fontWeight: '800',
      marginBottom: 24,
      textAlign: 'center',
      color: '#1A237E',
      letterSpacing: 0.5,
    },
    subtitle: {
      fontSize: 20,
      fontWeight: '700',
      marginBottom: 16,
      color: '#303F9F',
      letterSpacing: 0.25,
    },
    input: {
      height: 48,
      borderColor: '#E0E0E0',
      borderWidth: 1.5,
      borderRadius: 8,
      marginBottom: 16,
      paddingHorizontal: 16,
      backgroundColor: '#FFFFFF',
      fontSize: 16,
      color: '#424242',
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 1,
      },
      shadowOpacity: 0.1,
      shadowRadius: 2,
      elevation: 2,
    },
    button: {
      backgroundColor: '#2962FF',
      padding: 14,
      borderRadius: 8,
      alignItems: 'center',
      marginBottom: 20,
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.2,
      shadowRadius: 3,
      elevation: 3,
    },
    buttonText: {
      color: '#FFFFFF',
      fontWeight: '600',
      fontSize: 16,
      letterSpacing: 0.5,
    },
    stopContainer: {
      marginBottom: 16,
      backgroundColor: '#FFFFFF',
      padding: 16,
      borderRadius: 12,
      borderWidth: 1,
      borderColor: '#E0E0E0',
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 1,
      },
      shadowOpacity: 0.1,
      shadowRadius: 2,
      elevation: 2,
    },
    timePickerInput: {
      height: 48,
      borderColor: '#E0E0E0',
      borderWidth: 1.5,
      borderRadius: 8,
      marginBottom: 12,
      paddingHorizontal: 16,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#FFFFFF',
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 1,
      },
      shadowOpacity: 0.1,
      shadowRadius: 2,
      elevation: 2,
    },
    deleteButton: {
      backgroundColor: '#FF1744',
      padding: 12,
      borderRadius: 8,
      marginTop: 8,
      alignItems: 'center',
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.2,
      shadowRadius: 3,
      elevation: 3,
    },
    deleteButtonText: {
      color: '#FFFFFF',
      fontWeight: '600',
      fontSize: 14,
      letterSpacing: 0.25,
    },
    busInfo: {
      marginBottom: 20,
      padding: 16,
      borderWidth: 1,
      borderColor: '#E0E0E0',
      borderRadius: 12,
      backgroundColor: '#FFFFFF',
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.1,
      shadowRadius: 4,
      elevation: 3,
    },
  });
export default BusInfoPage;