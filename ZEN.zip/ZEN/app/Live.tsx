import { WebViewMessageEvent } from 'react-native-webview';
import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, ScrollView, Modal, TouchableOpacity, StatusBar, ActivityIndicator, FlatList,Alert} from 'react-native';
import WebView from 'react-native-webview';
import { MaterialIcons } from '@expo/vector-icons';
import { useRoute } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from "react-native-safe-area-context";

import { doc, getDoc, collection, getDocs, query, where } from "firebase/firestore";
import { db } from "./firebaseConfig";
type Stop = { 
  name: string; 
  timing: string;
};
type Bus = {name: string;routeNo: string;source: string;sourceTiming: string;destination: string;destinationTiming: string;stops: Stop[];
};type RouteParams = {
  datastoBus: string[];
};interface BusStop {
  timeSlot: string;
  stopName: string;
  arrivalTime: string;
}export default function BusRouteApp() {
  const [mapUrl, setMapUrl] = useState<string | null>(null);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [mapLoading, setMapLoading] = useState(true);
  const route = useRoute<any>();
  const { datastoBus } = route.params || { datastoBus: [] };
  const [busRoutes, setBusRoutes] = useState<string[]>([]);
  const [selectedRoute, setSelectedRoute] = useState<string | null>(null);
  const [buses, setBuses] = useState<Bus[]>([]);
  const [filteredRoutes, setFilteredRoutes] = useState<string[]>([]);
  const [partialMatchInfo, setPartialMatchInfo] = useState<{[key: string]: {sourceMatch: boolean, destMatch: boolean}}>({});
  // const [busRoutesValue, setbusRoutesValue] = useState<string[]>([]);
  const [busRoutesValue, setbusRoutesValue] = useState<string[]>([]);
  const [longitude, setLongitude] = useState<number | null>(null);
const [latitude, setLatitude] = useState<number | null>(null);

  const [longlatArray,SetlonglatArray]=useState([]);
  const fetchBusRoutes = async () => {
    try {
      setIsLoading(true);
      const docRef = doc(db, "Read", datastoBus[4]);
      const docSnap = await getDoc(docRef);
  
      if (docSnap.exists()) {
        const busesMap = docSnap.data().Buses || {}; 
        const routes = Object.keys(busesMap);  
        const values = Object.values(busesMap) as string[];
// SetlonglatArray({routes:values});
setbusRoutesValue(values); 
setBusRoutes(routes);
        if (datastoBus.length > 3) {
          await filterRoutesBySourceAndDestination(routes);
        } else {
          setFilteredRoutes(routes);
        }
      } else {
        console.log("No bus routes document found!");
      }
    } catch (error) {
      console.error("Error fetching bus routes:", error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const filterRoutesBySourceAndDestination = async (routes: string[]) => {
    const source = datastoBus[2].toLowerCase();
    const destination = datastoBus[3].toLowerCase();
    const filteredResults: string[] = [];
    const partialMatches: { [key: string]: { sourceMatch: boolean; destMatch: boolean } } = {};
    const sourceWords = source.split(/\s+/).filter((word: string) => word.length > 2);
const destWords = destination.split(/\s+/).filter((word: string) => word.length > 2);

    try {
      // Parallel Fetching: Reduce Firestore calls for better performance
      const routeDocs = await Promise.all(
        routes.map(async (routeNo) => {
          const docRef = doc(db, "Read", datastoBus[4], routeNo, "data");
          return getDoc(docRef).then(docSnap => ({ routeNo, docSnap }));
        })
      );
  
      for (const { routeNo, docSnap } of routeDocs) {
        if (!docSnap.exists()) continue;
  
        const data = docSnap.data();
        let busStops: string[] = [];
  
        // Extract all stop names while preserving order
        for (const timeSlot in data) {
          if (Object.prototype.hasOwnProperty.call(data, timeSlot)) {
            const stops = Object.keys(data[timeSlot]);
            busStops.push(...stops);
          }
        }
        const uniqueStops = Array.from(new Set(busStops.map(stop => stop.toLowerCase())));
  
        // **Enhanced Matching Logic**
        const sourceIndex = uniqueStops.findIndex(stop => stop.includes(source));
        const destIndex = uniqueStops.findIndex(stop => stop.includes(destination));
  
        // Ensure the source appears before the destination in the route
        if (sourceIndex !== -1 && destIndex !== -1 && sourceIndex < destIndex) {
          filteredResults.push(routeNo);
          partialMatches[routeNo] = { sourceMatch: true, destMatch: true };
          continue;
        }
        let hasPartialSource = uniqueStops.some((stop: string) => 
          sourceWords.every((word: string) => stop.includes(word))
      );
      let hasPartialDest = uniqueStops.some((stop: string) => 
          destWords.every((word: string) => stop.includes(word))
      );
      
        if (hasPartialSource && hasPartialDest) {
          filteredResults.push(routeNo);
          partialMatches[routeNo] = { sourceMatch: hasPartialSource, destMatch: hasPartialDest };
        }
      }
  
      setFilteredRoutes(filteredResults);
      setPartialMatchInfo(partialMatches);
    } catch (error) {
      console.error("Error filtering routes:", error);
      setFilteredRoutes([]);
    }
  };
  
  const fetchBusDetails = async (route: string) => {
    try {
      setIsLoading(true);
      const docRef = doc(db, "Read", datastoBus[4], route, "data");
      const docSnap = await getDoc(docRef);
  
      if (docSnap.exists()) {
        const data = docSnap.data();
        const busStops: BusStop[] = [];
  
        for (const timeSlot in data) {
          if (Object.prototype.hasOwnProperty.call(data, timeSlot)) {
            const stops = data[timeSlot];
  
            for (const stop in stops) {
              busStops.push({
                timeSlot,
                stopName: stop,
                arrivalTime: stops[stop],
              });
            }
          }
        }
        busStops.sort((a, b) => {
          const timeA = convertTimeTo24Hour(a.arrivalTime);
          const timeB = convertTimeTo24Hour(b.arrivalTime);
          return timeA - timeB;
        });
        if (busStops.length > 0) {
          const stopsArray: Stop[] = busStops.slice(1, -1).map(stop => ({
            name: stop.stopName,
            timing: formatTime(stop.arrivalTime),
          }));
          
          const newBus: Bus = {
            name: `Bus ${route}`,
            routeNo: route,
            source: busStops[0].stopName,
            sourceTiming: formatTime(busStops[0].arrivalTime),
            destination: busStops[busStops.length - 1].stopName,
            destinationTiming: formatTime(busStops[busStops.length - 1].arrivalTime),
            stops: stopsArray,
          };
          
          setBuses([newBus]);
        }
      } else {
        setBuses([]);
        console.log("No bus details found for route:", route);
      }
      setIsLoading(false);
    } catch (error) {
      console.error("Error fetching bus details:", error);
      setIsLoading(false);
    }
  };
  const convertTimeTo24Hour = (time: string): number => {
    const [hours, minutes] = time.split(".").map(Number);
    return hours * 60 + (minutes || 0); // Convert to total minutes
  };
  const formatTime = (timeStr: string): string => {
    const [hourStr, minuteStr] = timeStr.split(".");
    const hour = parseInt(hourStr);
    const minute = minuteStr ? parseInt(minuteStr) : 0;
    
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const hour12 = hour % 12 || 12;
    const minutePadded = minute < 10 ? `0${minute}` : minute;
    
    return `${hour12}:${minutePadded} ${ampm}`;
  };
  
  useEffect(() => {
    fetchBusRoutes();
  }, []);

  useEffect(() => {
    if (selectedRoute) {
      fetchBusDetails(selectedRoute);
    retrieveAllLiveGeoPoints();

    }
  }, [selectedRoute]);

  const handleBusSelection = (bus: Bus) => {
    const { source, destination, stops } = bus;
    if (source && destination && stops.length > 0) {
      const waypoints = [source, ...stops.map(stop => stop.name), destination];
      const apiKey = "pk.b2751cfe4d858539b81591e42aa1ce9d"; 
      const webViewContent = generateWebViewContent(waypoints, apiKey);
      setMapUrl(webViewContent);
      setIsModalVisible(true);
      setMapLoading(true);
    }
  };
const [geoPointsList, setGeoPointsList] = useState<{ fieldName: string; lat: number; lng: number }[]>([]);
  const [isFetchingLiveLocations, setIsFetchingLiveLocations] = useState(true);
  const [liveLocationError, setLiveLocationError] = useState<string | null>(null);
const retrieveAllLiveGeoPoints = async () => {
    try {
      setIsFetchingLiveLocations(true);
      setLiveLocationError(null);
      if (!datastoBus[4] || !selectedRoute) {
        console.error("Invalid values for Firestore path.");
        return;
      }
      
      const locationDocRef = doc(db, "Read", datastoBus[4], selectedRoute, "Location");
      const locationSnapshot = await getDoc(locationDocRef);
      if (locationSnapshot.exists()) {
        const locationData = locationSnapshot.data();
        const extractedGeoPoints: { fieldName: string; lat: number; lng: number }[] = [];
        for (const key in locationData) {
          const fieldValue = locationData[key];
          if (fieldValue && typeof fieldValue === "object" && "latitude" in fieldValue && "longitude" in fieldValue) {
            extractedGeoPoints.push({
              fieldName: key,
              lat: fieldValue.latitude,
              lng: fieldValue.longitude,
            });
          }
        }
        if (extractedGeoPoints.length > 0) {
          setGeoPointsList(extractedGeoPoints);
          const matchingPoint = extractedGeoPoints.find(point => busRoutesValue.includes(point.fieldName));
            if (matchingPoint) {
            setLatitude(matchingPoint.lat); 
            setLongitude(matchingPoint.lng);
          }
        }
        else {
          console.warn("No valid GeoPoint fields found.");
          setGeoPointsList([]);
        }
      } else {
        console.warn("No location document found!");
        setGeoPointsList([]);
      }
    } catch (err) {
      console.error("Error fetching live locations:", err);
      Alert.alert(`Error${err}`)
      setLiveLocationError("Failed to retrieve live location data.");
    } finally {
      setIsFetchingLiveLocations(false);
    }
  };
  const generateWebViewContent = (waypoints: string[], apiKey: string) => {
    const liveLocationCoords = { lat: latitude, lng: longitude};
  
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
          <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
          <link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine@3.2.12/dist/leaflet-routing-machine.css" />
          <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
          <script src="https://unpkg.com/leaflet-routing-machine@3.2.12/dist/leaflet-routing-machine.js"></script>
          <style>
            body { margin: 0; padding: 0; }
            #map { width: 100vw; height: 100vh; }
            .live-location-icon {
              border-radius: 50%;
              border: 2px solid white;
              box-shadow: 0 0 10px rgba(0,0,0,0.5);
            }
            .pulsating-circle {
              border-radius: 50%;
              transform: scale(1);
              animation: pulse 2s infinite;
              box-shadow: 0 0 0 0 rgba(255, 0, 0, 0.7);
            }
            @keyframes pulse {
              0% {
                transform: scale(0.95);
                box-shadow: 0 0 0 0 rgba(255, 0, 0, 0.7);
              }
              70% {
                transform: scale(1);
                box-shadow: 0 0 0 10px rgba(255, 0, 0, 0);
              }
              100% {
                transform: scale(0.95);
                box-shadow: 0 0 0 0 rgba(255, 0, 0, 0);
              }
            }
          </style>
        </head>
        <body>
          <div id="map"></div>
          <script>
            (function() {
              const waypoints = ${JSON.stringify(waypoints)};
              const apiKey = "${apiKey}";
              const liveLocation = ${JSON.stringify(liveLocationCoords)};
              
              // Initialize the map centered on the live location
              const map = L.map('map').setView([liveLocation.lat, liveLocation.lng], 12);
  
              L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
              }).addTo(map);
  
              // Create a custom icon for the live location
              const liveIcon = L.divIcon({
                className: 'live-location-icon pulsating-circle',
                iconSize: [20, 20],
                html: '<div style="background-color: red; width: 100%; height: 100%; border-radius: 50%;"></div>'
              });
  
              // Add the live location marker
              const liveMarker = L.marker([liveLocation.lat, liveLocation.lng], {
                icon: liveIcon,
                zIndexOffset: 1000 // Ensure it appears above other markers
              }).addTo(map);
  
              liveMarker.bindPopup("<b>${selectedRoute} Location</b>").openPopup();
  
              async function getCoordinates(placeName) {
                try {
                  const url = \`https://us1.locationiq.com/v1/search.php?key=\${apiKey}&q=\${encodeURIComponent(placeName)}&format=json\`;
                  const response = await fetch(url);
                  const data = await response.json();
                  if (data && data.length > 0) {
                    return { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) };
                  }
                  throw new Error('Location not found: ' + placeName);
                } catch (error) {
                  console.error('Error fetching coordinates:', error);
                  return null;
                }
              }
  
              // Custom icon for regular stops
              const regularIcon = L.icon({
                iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
                iconSize: [25, 41],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34],
                shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
                shadowSize: [41, 41]
              });
  
              async function processStops() {
                const coordinates = [];
                for (const waypoint of waypoints) {
                  const coords = await getCoordinates(waypoint);
                  if (coords) {
                    coordinates.push(coords);
                    L.marker([coords.lat, coords.lng], {
                      icon: regularIcon
                    })
                      .addTo(map)
                      .bindPopup(waypoint);
                  }
                }
  
                if (coordinates.length >= 2) {
                  const routePoints = coordinates.map(coord => L.latLng(coord.lat, coord.lng));
                  L.Routing.control({
                    waypoints: routePoints,
                    routeWhileDragging: true,
                    router: L.Routing.osrmv1({
                      serviceUrl: 'https://router.project-osrm.org/route/v1'
                    }),
                    createMarker: function() { return null; }, // Don't create default markers
                    show: false,
                    lineOptions: {
                      styles: [{ color: '#1a73e8', opacity: 0.7, weight: 5 }]
                    }
                  }).addTo(map);
  
                  // Include the live location in the bounds calculation
                  const allPoints = [...routePoints, L.latLng(liveLocation.lat, liveLocation.lng)];
                  const bounds = L.latLngBounds(allPoints);
                  map.fitBounds(bounds, { padding: [50, 50] });
                }
  
                window.ReactNativeWebView.postMessage('mapLoaded');
              }
  
              processStops();
            })();
          </script>
        </body>
      </html>
    `;
  };
  const handleMessage = (event: WebViewMessageEvent) => {
    if (event.nativeEvent.data === 'mapLoaded') {
      setMapLoading(false);
    }
  };
  const renderBusRouteItem = ({ item }: { item: string }) => {
    const isPartialMatch = partialMatchInfo[item] && 
      (!partialMatchInfo[item].sourceMatch || !partialMatchInfo[item].destMatch);
    return (
      <TouchableOpacity 
        style={[
          styles.busRouteItem, 
          selectedRoute === item && styles.selectedRouteItem,
          isPartialMatch && styles.partialMatchItem
        ]}
        onPress={() => setSelectedRoute(item)}
      >
        <Text style={[
          styles.busRouteText, 
          selectedRoute === item && { color: '#fff' },
          isPartialMatch && { color: selectedRoute === item ? '#fff' : '#d76b00' }
        ]}>{item}</Text>
        {isPartialMatch && (
          <Text style={[
            styles.partialMatchText,
            selectedRoute === item && { color: '#fff' }
          ]}>Partial Match</Text>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.safeArea}>
         <StatusBar backgroundColor="#070718" barStyle="light-content" />
      <LinearGradient
        colors={['#7A5FFF', '#5345D9']}
        style={styles.header}
      >
        {datastoBus && datastoBus.length > 1 && (
          <>
            <Text style={styles.headerTitle}>Live Buses in {`${datastoBus[4]}`}</Text>
            <Text style={styles.headerSubtitle}>
              {`${datastoBus[0]} to ${datastoBus[1]}`}
            </Text>
            {/* <Text style={{color:'white'}}>{datastoBus[0]}</Text>
            <Text style={{color:'white'}}>{datastoBus[1]}</Text>
            <Text style={{color:'white'}}>{datastoBus[2]}</Text>
            <Text style={{color:'white'}}>Bus Route{busRoutes}{'\n Value is '+busRoutesValue}</Text>
            {/* <Text style={{color:'white'}}>{selectedRoute}{Latitude}</Text> */}
            {/* <Text style={{color:'white'}}>{latitude}:{longitude}</Text>
            <View>
  {geoPointsList.map((geo, index) => (
    <Text key={index} style={styles.liveLocationText}>
      📍 {geo.fieldName}: Latitude: {geo.lat}, Longitude: {geo.lng}
    </Text>
  ))}
</View>  */}

          </>
        )}
      </LinearGradient>
      
      <View style={styles.routesContainer}>
        <View style={styles.routesHeader}>
          {filteredRoutes.length > 0 && (
            <Text style={styles.routeCount}>{filteredRoutes.length} routes found</Text>
          )}
        </View>
        {isLoading && filteredRoutes.length === 0 ? (
          <ActivityIndicator size="large" color="#1a73e8" />
        ) : filteredRoutes.length > 0 ? (
          <>
            <FlatList
              data={filteredRoutes}
              renderItem={renderBusRouteItem}
              keyExtractor={(item) => item}
              horizontal
              showsHorizontalScrollIndicator={false}
              style={styles.routesList}
            />
            <Text style={styles.matchLegend}>
              <MaterialIcons name="info-outline" size={14} color="#d76b00" />Places Found</Text>
          </>
        ) : (
          <Text style={styles.noRoutesText}>No routes available for this section</Text>
        )}
      </View>

      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        {isLoading && selectedRoute ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#1a73e8" />
            <Text style={styles.loadingText}>Loading bus details...</Text>
          </View>
        ) : (
          buses.map((bus) => (
            <View
              key={bus.routeNo}
              style={styles.busBox}
            >
              <View style={styles.busHeader}>
                <View>
                  <Text style={styles.busName}>{bus.name}</Text>
                  <Text style={styles.routeNo}>Route {bus.routeNo}</Text>
                  {partialMatchInfo[bus.routeNo] && 
                    (!partialMatchInfo[bus.routeNo].sourceMatch || !partialMatchInfo[bus.routeNo].destMatch) && (
                    <Text style={styles.partialMatchAlert}>
                      <MaterialIcons name="info-outline" size={14} color="#d76b00" /> Partial match
                    </Text>
                  )}
                </View>
                <MaterialIcons name="directions-bus" size={24} color="#1a73e8" />
              </View>

              <View style={styles.routeContainer}>
                <View style={styles.routeEndpoint}>
                  <MaterialIcons name="radio-button-checked" size={20} color="#1a73e8" />
                  <View style={styles.routeTextContainer}>
                    <Text style={styles.routeText}>{bus.source}</Text>
                    <Text style={styles.routeLabel}>{bus.sourceTiming}</Text>
                  </View>
                </View>

                {bus.stops.map((stop, index) => (
                  <View key={index} style={styles.routeStop}>
                    <View style={styles.stopLine} />
                    <MaterialIcons name="fiber-manual-record" size={16} color="#5f6368" />
                    <View style={styles.routeTextContainer}>
                      <Text style={styles.stopText}>{stop.name}</Text>
                      <Text style={styles.timingText}>{stop.timing}</Text>
                    </View>
                  </View>
                ))}

                <View style={styles.routeEndpoint}>
                  <MaterialIcons name="place" size={20} color="#ea4335" />
                  <View style={styles.routeTextContainer}>
                    <Text style={styles.routeText}>{bus.destination}</Text>
                    <Text style={styles.routeLabel}>{bus.destinationTiming}</Text>
                  </View>
                </View>
              </View>

              <TouchableOpacity onPress={() => handleBusSelection(bus)} style={styles.viewRouteButton}>
                <Text style={styles.viewRouteText}>View Route Map</Text>
                <MaterialIcons name="arrow-forward" size={20} color="#1a73e8" />
              </TouchableOpacity>
            </View>
          ))
        )}
        
        {selectedRoute && buses.length === 0 && !isLoading && (
          <View style={styles.noDataContainer}>
            <MaterialIcons name="info-outline" size={36} color="#5f6368" />
            <Text style={styles.noDataText}>No bus data available for this route</Text>
          </View>
        )}
        
        {!selectedRoute && (
          <View style={styles.instructionContainer}>
            <MaterialIcons name="touch-app" size={36} color="#1a73e8" />
            <Text style={styles.instructionText}>
              {filteredRoutes.length > 0 
                ? "Please select a bus route above to see details" 
                : "If The Route Found You can Select The Button & See The Route"}
            </Text>
          </View>
        )}
      </ScrollView>

      <Modal
        visible={isModalVisible}
        animationType="slide"
        transparent={false}
        onRequestClose={() => setIsModalVisible(false)}
      >
        <SafeAreaView style={styles.modalContainer}>
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => setIsModalVisible(false)}
          >
            <MaterialIcons name="close" size={24} color="#fff" />
          </TouchableOpacity>
          {mapUrl && (
            <WebView
              source={{ html: mapUrl }}
              style={styles.webviewFullScreen}
              onMessage={handleMessage}
              javaScriptEnabled={true}
              domStorageEnabled={true}
            />
          )}
          {mapLoading && (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#1a73e8" />
              <Text style={styles.loadingText}>Loading map...</Text>
            </View>
          )}
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#121212', // Dark background
  },
  header: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#2a2a2a',borderBottomLeftRadius:35,borderBottomRightRadius:35
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff', 
    textAlign: 'center',
  },
  headerSubtitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#e0e0e0', // Light gray for dark theme
    marginTop: 4,
    textAlign: 'center',
  },
  routeFilter: {
    fontSize: 14,
    color: '#7A5FFF', // Primary accent color
    marginTop: 8,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  routesContainer: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#2a2a2a', // Darker border
  },
  routesHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff', // White text
  },
  routeCount: {
    fontSize: 14,
    color: '#b0b0b0', // Light gray
  },
  routesList: {
    flexGrow: 0,
  },
  busRouteItem: {
    backgroundColor: '#2a2a2a', // Dark gray background
    padding: 10,
    marginRight: 10,
    borderRadius: 8,
  },
  selectedRouteItem: {
    backgroundColor: '#7A5FFF', // Primary accent color
  },
  partialMatchItem: {
    backgroundColor: '#332c4a', // Darker shade of purple
    borderWidth: 1,
    borderColor: '#5345D9', // Secondary accent color
  },
  busRouteText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff', // White text
  },
  partialMatchText: {
    fontSize: 10,
    fontWeight: '500',
    color: '#a195ff', // Lighter shade of primary color
    marginTop: 2,
  },
  matchLegend: {
    fontSize: 12,
    color: '#b0b0b0', // Light gray
    marginTop: 8,
    fontStyle: 'italic',
  },
  noRoutesText: {
    fontSize: 14,
    color: '#b0b0b0', // Light gray
    fontStyle: 'italic',
    marginTop: 10,
  },
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#121212', // Dark background
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#121212', // Dark background
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#b0b0b0', // Light gray
  },
  noDataContainer: {
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#1e1e1e', // Slightly lighter than background
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 3,
  },
  noDataText: {
    marginTop: 10,
    fontSize: 16,
    color: '#b0b0b0', // Light gray
    textAlign: 'center',
  },
  instructionContainer: {
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#1e1e1e', // Slightly lighter than background
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 3,
  },
  instructionText: {
    marginTop: 10,
    fontSize: 16,
    color: '#7A5FFF', // Primary accent color
    textAlign: 'center',
    fontWeight: '500',
  },
  busBox: {
    backgroundColor: '#1e1e1e', // Slightly lighter than background
    padding: 20,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 3,
  },
  busHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  busName: {
    fontSize: 20,
    fontWeight: '600',
    color: '#ffffff', // White text
  },
  routeNo: {
    fontSize: 14,
    fontWeight: '400',
    color: '#b0b0b0', // Light gray
    marginTop: 4,
  },
  partialMatchAlert: {
    fontSize: 12,
    fontWeight: '500',
    color: '#a195ff', // Lighter shade of primary color
    marginTop: 4,
  },
  routeContainer: {
    marginTop: 8,
  },
  routeEndpoint: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 8,
  },
  routeStop: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 2,
    marginVertical: 8,
  },
  stopLine: {
    position: 'absolute',
    left: 9,
    top: -16,
    bottom: -16,
    width: 2,
    backgroundColor: '#2a2a2a', // Darker border
  },
  routeTextContainer: {
    marginLeft: 12,
    flex: 1,
  },
  routeText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#ffffff', // White text
  },
  routeLabel: {
    fontSize: 13,
    fontWeight: '400',
    color: '#b0b0b0', // Light gray
    marginTop: 2,
  },  
  stopText: {
    fontSize: 15,
    fontWeight: '400',
    color: '#ffffff', // White text
  },
  timingText: {
    fontSize: 13,
    fontWeight: '400',
    color: '#b0b0b0', // Light gray
    marginTop: 2,
  },
  viewRouteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#2a2a2a', // Darker border
  },
  viewRouteText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#7A5FFF', // Primary accent color
    marginRight: 8,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#000', // Black background for modal
  },
  webviewFullScreen: {
    flex: 1,
  },
  closeButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    zIndex: 1,
    backgroundColor: 'rgba(83, 69, 217, 0.8)', // Secondary accent color with transparency
    padding: 8,
    borderRadius: 20,
  },
});